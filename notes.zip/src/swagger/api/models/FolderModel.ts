/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type FolderModel = {
    description: string;
    name: string;
    id: string;
};

/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { FolderModel } from './FolderModel';

export type GetAllUserFoldersResDTO = {
    folders: Array<FolderModel>;
};

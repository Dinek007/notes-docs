/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type SignupReqDTO = {
    email: string;
    password: string;
    name: string;
};

/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type FolderWithNotes = {
    description: string;
    name: string;
    id: string;
    notesCnt: number;
};

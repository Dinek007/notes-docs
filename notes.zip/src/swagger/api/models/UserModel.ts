/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type UserModel = {
    email: string;
    name: string;
    id: string;
};

/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type NoteModel = {
    name: string;
    content: string;
    'x': number;
    'y': number;
    width: number;
    height: number;
    zIndex: number;
    color: string;
    userId: string;
    folderId: string;
    id: string;
};

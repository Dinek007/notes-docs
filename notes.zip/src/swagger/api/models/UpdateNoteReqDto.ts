/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type UpdateNoteReqDto = {
    name?: string;
    content?: string;
    'x'?: number;
    'y'?: number;
    width?: number;
    height?: number;
    zIndex?: number;
    color?: string;
    folderId?: string;
};

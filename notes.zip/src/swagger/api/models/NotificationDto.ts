/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { NotificationModel } from './NotificationModel';

export type NotificationDto = {
  notification?: NotificationModel;
};

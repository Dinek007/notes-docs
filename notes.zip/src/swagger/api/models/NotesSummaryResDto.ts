/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { FolderWithNotes } from './FolderWithNotes';

export type NotesSummaryResDto = {
    foldersCnt: number;
    folders: Array<FolderWithNotes>;
};

/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CreateNoteReqDto = {
    name: string;
    content: string;
    'x': number;
    'y': number;
    width: number;
    height: number;
    zIndex: number;
    color: string;
    folderId: string;
};

/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CreateOneTimeNotificationDto = {
    name: string;
    noteId: string;
    triggerTime: string;
};

/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { NoteModel } from './NoteModel';

export type GetFolderNotesResDTO = {
    notes: Array<NoteModel>;
};

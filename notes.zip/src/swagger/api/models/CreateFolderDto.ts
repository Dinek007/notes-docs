/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CreateFolderDto = {
    description: string;
    name: string;
};

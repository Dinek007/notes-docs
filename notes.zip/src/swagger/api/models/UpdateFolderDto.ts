/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type UpdateFolderDto = {
    description?: string;
    name?: string;
};

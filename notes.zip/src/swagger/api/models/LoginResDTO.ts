/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { UserModel } from './UserModel';

export type LoginResDTO = {
    user: UserModel;
    accessToken: string;
};

import { FieldError } from 'react-hook-form';

export type FieldErrorMessageProps = {
  error?: FieldError;
};

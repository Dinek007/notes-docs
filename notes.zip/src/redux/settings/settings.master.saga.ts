import { all, takeEvery } from "typed-redux-saga";

export function* settingsMasterSaga(): Generator {
  yield all([]);
}

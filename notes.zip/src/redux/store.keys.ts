export enum StoreKeys {
  Session = "session",
  Navigation = "navigation",
  Notes = "notes",
  Settings = "settings",
}

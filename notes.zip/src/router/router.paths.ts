export enum RouterPaths {
  Root = "/",
  Login = "/login",
  SignUp = "/sign-up",
  Notes = "/notes",
}


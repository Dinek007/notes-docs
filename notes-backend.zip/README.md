## Description

[Nest](https://github.com/nestjs/nest) framework TypeScript starter repository.

## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ yarn run start

# watch mode
$ yarn run start:dev

# production mode
$ yarn run start:prod
```

## Test

```bash
# unit tests
$ yarn run test

# e2e tests
$ yarn run test:e2e

# test coverage
$ yarn run test:cov
```

## Local faunadb setup:

```bash
# initialize docker, setup faunadb endpoint, database and key by running
$ yarn fauna-dev

# set generated keys to env
$ export $(grep -v '^#' .env.local | xargs)

# run migrations and fill initial data
$ yarn init-db
```

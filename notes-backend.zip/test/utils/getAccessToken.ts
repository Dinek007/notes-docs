import { sign } from 'jsonwebtoken';

import { UserModel } from '../../src/user/user.dto';
import { mockJwtSecret } from '../../src/config/config';

export const getAccessToken = (user: UserModel): string => {
  const userId = user.id;

  const accessToken = sign({ userId }, mockJwtSecret);

  return accessToken;
};

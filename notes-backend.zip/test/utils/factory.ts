import faunadb, { query as q } from 'faunadb';

import {
  FolderQueryResult,
  FoldersQueryResult,
} from '../../src/folders/folders.types';
import { FaunaQuery } from '../../src/types';
import { SignupReqDTO, UserModel } from '../../src/user/user.dto';
import { UserDbData, UserQueryResult } from '../../src/user/user.types';
import { CreateNoteReqDto, NoteModel } from '../../src/notes/notes.dto';
import { CreateFolderDto, FolderModel } from '../../src/folders/folders.dto';
import { NoteQueryResult, NotesQueryResult } from '../../src/notes/notes.types';
import {
  NotificationModel,
  NotificationType,
} from '../../src/notifications/notifications.dto';
import {
  NotificationQueryResult,
  NotificationsQueryResult,
} from '../../src/notifications/notifications.types';

export class FaunaFactory {
  constructor(private readonly dbClient: faunadb.Client) {}

  async addUser(userData: SignupReqDTO): Promise<UserModel> {
    const { password, email, name } = userData;

    const user = {
      credentials: { password },
      data: { email, name },
    };

    const { ref, data } = await this.dbClient.query<UserQueryResult>(
      q.Create(q.Collection('Users'), user),
    );

    return { ...data, id: ref.id };
  }

  async getUsers() {
    const { data } = await this.dbClient.query<FaunaQuery<UserDbData[]>>(
      q.Map(
        q.Paginate(q.Documents(q.Collection('Users'))),
        q.Lambda((x) => q.Select(['data'], q.Get(x))),
      ),
    );

    return data;
  }

  async addFolder(
    folderData: Partial<CreateFolderDto> & { userId: string },
  ): Promise<FolderModel> {
    const defaultFolder: Partial<CreateFolderDto> = {
      name: 'folder name',
      description: 'folder desc',
    };

    const { userId, ...folderToAdd } = folderData;

    const folder = {
      data: {
        ...defaultFolder,
        ...folderToAdd,
        user: q.Ref(q.Collection('Users'), userId),
      },
    };

    const { ref, data } = await this.dbClient.query<FolderQueryResult>(
      q.Create(q.Collection('Folders'), folder),
    );

    return { ...data, id: ref.id };
  }

  async getUserFolders(userId: string): Promise<FolderModel[]> {
    const res = await this.dbClient.query<FoldersQueryResult>(
      q.Map(
        q.Paginate(
          q.Match(
            q.Index('folders_by_user'),
            q.Ref(q.Collection('Users'), userId),
          ),
        ),
        q.Lambda('ref', q.Get(q.Var('ref'))),
      ),
    );

    const parsed = res.data.map(({ data: { description, name }, ref }) => ({
      id: ref.id,
      description,
      name,
    }));

    return parsed;
  }

  async addNote(
    folderData: Partial<CreateNoteReqDto> & { userId: string },
  ): Promise<NoteModel> {
    const defaultNote: Partial<CreateNoteReqDto> = {
      content: 'note content',
      name: 'note name',
      x: 100,
      y: 150,
      color: '#ffffff',
      height: 100,
      width: 100,
      zIndex: 150,
    };

    const { folderId, userId, ...noteData } = folderData;

    const note = {
      data: {
        ...defaultNote,
        ...noteData,
        folder: q.Ref(q.Collection('Folders'), folderId),
        user: q.Ref(q.Collection('Users'), userId),
      },
    };

    const {
      data: { folder, user, ...addedNoteData },
      ref,
    } = await this.dbClient.query<NoteQueryResult>(
      q.Create(q.Collection('Notes'), note),
    );

    return {
      ...addedNoteData,
      id: ref.id,
      userId: user.id,
      folderId: folder.id,
    };
  }

  async getUserNotes(userId: string): Promise<NoteModel[]> {
    const res = await this.dbClient.query<NotesQueryResult>(
      q.Map(
        q.Paginate(
          q.Match(
            q.Index('notes_by_user'),
            q.Ref(q.Collection('Users'), userId),
          ),
        ),
        q.Lambda('ref', q.Get(q.Var('ref'))),
      ),
    );

    const parsed = res.data.map(
      ({ data: { folder, user, ...baseNoteData }, ref }): NoteModel => ({
        ...baseNoteData,
        id: ref.id,
        userId: user.id,
        folderId: folder.id,
      }),
    );

    return parsed;
  }

  async addNotification(
    notification: Partial<NotificationModel> & {
      userId: string;
      noteId: string;
    },
  ): Promise<NotificationModel> {
    const defaultNotification: Partial<NotificationModel> = {
      name: 'notification name',
      type: NotificationType.OneTime,
      expression: `cron(10 10 1 1 ? 2023)`,
    };

    const { noteId, userId, ...notificationData } = notification;

    const data = {
      data: {
        ...defaultNotification,
        ...notificationData,
        note: q.Ref(q.Collection('Notes'), noteId),
        user: q.Ref(q.Collection('Users'), userId),
      },
    };

    const {
      data: { user, note, ...addedNotification },
      ref,
    } = await this.dbClient.query<NotificationQueryResult>(
      q.Create(q.Collection('Notifications'), data),
    );

    return {
      ...addedNotification,
      id: ref.id,
      userId: user.id,
      noteId: note.id,
    };
  }

  async getUserNotifications(userId: string): Promise<NotificationModel[]> {
    const res = await this.dbClient.query<NotificationsQueryResult>(
      q.Map(
        q.Paginate(
          q.Match(
            q.Index('notifications_by_user'),
            q.Ref(q.Collection('Users'), userId),
          ),
        ),
        q.Lambda('ref', q.Get(q.Var('ref'))),
      ),
    );

    const parsed = res.data.map(
      ({ data: { note, user, ...baseNoteData }, ref }): NotificationModel => ({
        ...baseNoteData,
        id: ref.id,
        userId: user.id,
        noteId: note.id,
      }),
    );

    return parsed;
  }
}

export const AwsSESMock = {
  sendEmail: jest.fn().mockReturnValue({ promise: jest.fn() }),
};

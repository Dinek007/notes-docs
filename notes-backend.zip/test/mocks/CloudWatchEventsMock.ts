import { CloudWatchEvents } from 'aws-sdk';

type CloudWatchEventsMock = {
  [method in keyof CloudWatchEvents]: jest.Mock;
};

export const CloudWatchEventsMock: CloudWatchEventsMock = {
  putRule: jest.fn().mockReturnValue({ promise: jest.fn() }),
  deleteRule: jest.fn().mockReturnValue({ promise: jest.fn() }),
  putTargets: jest.fn().mockReturnValue({ promise: jest.fn() }),
  listTargetsByRule: jest.fn().mockReturnValue({ promise: jest.fn() }),
  removeTargets: jest.fn().mockReturnValue({ promise: jest.fn() }),
} as CloudWatchEventsMock;

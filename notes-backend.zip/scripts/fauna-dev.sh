#!/usr/bin/env bash

KEY=secret
ENDPOINT_NAME=localhost
FAUNA_PORT=8443

docker pull fauna/faunadb
docker container stop faunadb || true && docker container rm faunadb || true
CID=$(docker run --name faunadb -d \
  --health-cmd="faunadb-admin status" --health-interval=2s \
  -p ${FAUNA_PORT}:8443 \
  -p 6379:8084 \
  fauna/faunadb)

./scripts/wait-for-healthy.sh faunadb 30

ENDPOINT_EXIST=$(yarn fauna list-endpoints | grep ${ENDPOINT_NAME})

if [ -z "$ENDPOINT_EXIST" ]
then
  echo n | yarn fauna add-endpoint http://localhost:${FAUNA_PORT}/ --alias ${ENDPOINT_NAME} --key ${KEY}
else
  echo "endpoint ${ENDPOINT_NAME} already exist"
fi

yarn fauna create-database notes --endpoint ${ENDPOINT_NAME} --secret ${KEY}
OUTPUT=$(yarn fauna create-key notes --endpoint ${ENDPOINT_NAME} --secret ${KEY})

[[ "${OUTPUT}" =~ secret\:[[:space:]]([A-Za-z0-9_\-]+) ]]

echo "${OUTPUT}"

SECRET="${BASH_REMATCH[1]}"
echo "Secret: ${SECRET}"
echo "Docker container: $CID"

DOCKER_IP=$(docker inspect $CID | grep '"IPAddress"' | head -n 1)
DOCKER_IP=$(echo $DOCKER_IP | sed -E -e 's/ |"|:|,|IPAddress//g')

echo "Docker IP: ${DOCKER_IP}"

echo "JWT_SECRET=test
DB=local
FAUNADB_SCHEME=http
FAUNA_ADMIN_KEY=${SECRET}
FAUNADB_PORT=${FAUNA_PORT}
FAUNADB_DOMAIN=${DOCKER_IP}" > ".env.local";

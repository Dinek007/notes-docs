import { createApp } from './createApp';

async function bootstrap() {
  const app = await createApp({
    logger: ['error', 'warn', 'log', 'verbose', 'debug'],
  });

  app.listen(3000);
}
bootstrap();

import { NestFactory } from '@nestjs/core';

import { AppModule } from '../app.module';
import { NotificationsService } from '../notifications/notifications.service';

let notificationsService: NotificationsService;

export const getNotificationsService =
  async (): Promise<NotificationsService> => {
    if (!notificationsService) {
      const appModule = await NestFactory.createApplicationContext(AppModule, {
        abortOnError: true,
      });

      notificationsService = appModule.get(NotificationsService);
    }

    return notificationsService;
  };

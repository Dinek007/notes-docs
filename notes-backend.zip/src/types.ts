export type Ref = { id: string };

export type FaunaQuery<Data> = {
  data: Data;
  ref: Ref;
};

export type DeepPartial<T> = T extends object
  ? {
      [P in keyof T]?: DeepPartial<T[P]>;
    }
  : T;

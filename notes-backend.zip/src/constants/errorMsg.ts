export enum MSG {
  USER_NOT_FOUND = 'User not found. Email or password is incorrect',
  USER_ALREADY_EXISTS = 'User already exists',
  FOLDER_DOES_NOT_BELONG_TO_USER = 'User is not the owner of the folder',
  NOTE_DOES_NOT_BELONG_TO_USER = 'User is not the owner of the note',
  NOTE_NOT_FOUND = 'Note not found',
  FOLDER_NAME_DUPLICATE = 'User already has a folder with the specified name',
  NOTIFICATION_NOT_FOUND = 'Notification not found',
  NOTIFICATION_DOES_NOT_BELONG_TO_USER = 'User is not the owner of the notification',
}

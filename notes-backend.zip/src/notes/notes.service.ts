import { BadRequestException, Injectable } from '@nestjs/common';
import { FaunadbService, Client, query as q, ExprArg } from 'nestjs-faunadb';

import { MSG } from '../constants/errorMsg';
import { FoldersService } from '../folders/folders.service';

import { NoteQueryResult, NotesQueryResult } from './notes.types';
import {
  NoteModel,
  UpdateNoteReqDto,
  CreateNoteReqDto,
  GetFolderNotesResDTO,
  NotesSummaryResDto,
  FolderWithNotes,
} from './notes.dto';
import { FaunaQuery } from '../types';

@Injectable()
export class NotesService {
  private faunaClient: Client;

  constructor(
    faunaService: FaunadbService,
    private readonly foldersService: FoldersService,
  ) {
    this.faunaClient = faunaService.getClient();
  }

  private parseNoteData({ ref, data }: NoteQueryResult): NoteModel {
    const { user, folder, ...filteredData } = data;

    return {
      id: ref.id,
      userId: user.id,
      folderId: folder.id,
      ...filteredData,
    };
  }

  async createNote(
    userId: string,
    createNoteDto: CreateNoteReqDto,
  ): Promise<NoteModel> {
    const { folderId, ...noteData } = createNoteDto;

    await this.foldersService.findUserFolder(userId, folderId);

    const note = {
      data: {
        ...noteData,
        folder: q.Ref(q.Collection('Folders'), folderId),
        user: q.Ref(q.Collection('Users'), userId),
      },
    };

    const noteRes = await this.faunaClient.query<NoteQueryResult>(
      q.Create(q.Collection('Notes'), note),
    );

    return this.parseNoteData(noteRes);
  }

  async getFolderNotes(
    userId: string,
    folderId: string,
  ): Promise<GetFolderNotesResDTO> {
    await this.foldersService.findUserFolder(userId, folderId);

    const { data: notesData } = await this.faunaClient.query<NotesQueryResult>(
      q.Map(
        q.Paginate(
          q.Match(
            q.Index('notes_by_folder'),
            q.Ref(q.Collection('Folders'), folderId),
          ),
        ),
        q.Lambda('ref', q.Get(q.Var('ref'))),
      ),
    );

    const parsedNotes: NoteModel[] = notesData.map(this.parseNoteData);

    return {
      notes: parsedNotes,
    };
  }

  private async getFolderNotesCount(folderId: string): Promise<number> {
    const { data } = await this.faunaClient.query<FaunaQuery<number[]>>(
      q.Count(
        q.Paginate(
          q.Match(
            q.Index('notes_by_folder'),
            q.Ref(q.Collection('Folders'), folderId),
          ),
        ),
      ),
    );

    return data[0];
  }

  async findUserNote(userId: string, noteId: string): Promise<NoteModel> {
    let noteRes: NoteQueryResult;

    try {
      noteRes = await this.faunaClient.query<NoteQueryResult>(
        q.Get(q.Match(q.Index('note_by_id'), noteId)),
      );
    } catch (e) {
      throw new BadRequestException(MSG.NOTE_NOT_FOUND);
    }

    if (noteRes.data.user.id !== userId) {
      throw new BadRequestException(MSG.NOTE_DOES_NOT_BELONG_TO_USER);
    }

    const parsedFolder = this.parseNoteData(noteRes);

    return parsedFolder;
  }

  async updateNote(
    noteId: string,
    userId: string,
    updateNoteDto: UpdateNoteReqDto,
  ) {
    const { folderId, ...noteData } = updateNoteDto;
    const existingNote = await this.findUserNote(userId, noteId);

    const updateData: ExprArg = {
      data: {
        ...existingNote,
        ...noteData,
      },
    };

    if (folderId) {
      await this.foldersService.findUserFolder(userId, folderId);

      updateData.data.folder = q.Ref(q.Collection('Folders'), folderId);
    }

    const updated = await this.faunaClient.query<NoteQueryResult>(
      q.Update(q.Ref(q.Collection('Notes'), noteId), updateData),
    );

    return this.parseNoteData(updated);
  }

  async removeNote(userId: string, noteId: string) {
    await this.findUserNote(userId, noteId);

    await this.faunaClient.query<NoteQueryResult>(
      q.Delete(q.Ref(q.Collection('Notes'), noteId)),
    );
  }

  async getNotesSummary(userId: string): Promise<NotesSummaryResDto> {
    const userFolders = await this.foldersService.getUserFolders(userId);

    const foldersWithNotes: FolderWithNotes[] = await Promise.all(
      userFolders.folders.map(async (folder) => {
        return {
          ...folder,
          notesCnt: await this.getFolderNotesCount(folder.id),
        };
      }),
    );

    return {
      folders: foldersWithNotes,
      foldersCnt: foldersWithNotes.length,
    };
  }
}

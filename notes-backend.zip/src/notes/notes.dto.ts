import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsHexColor, IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { FolderModel } from '../folders/folders.dto';

export class NoteModelBase {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  name: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  content: string;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  x: number;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  y: number;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  width: number;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  height: number;

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  zIndex: number;

  @IsHexColor()
  @IsNotEmpty()
  @ApiProperty()
  color: string;
}

export class NoteModel extends NoteModelBase {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  userId: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  folderId: string;

  @ApiProperty()
  id: string;
}

export class CreateNoteReqDto extends NoteModelBase {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  folderId: string;
}

export class UpdateNoteReqDto extends PartialType(CreateNoteReqDto) {}

export class GetFolderNotesResDTO {
  notes: NoteModel[];
}

export class FolderWithNotes extends FolderModel {
  notesCnt: number;
}

export class NotesSummaryResDto {
  foldersCnt: number;
  folders: FolderWithNotes[];
}

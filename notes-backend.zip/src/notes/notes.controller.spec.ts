import request from 'supertest';
import { ConfigModule } from '@nestjs/config';
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';

import { FaunaFactory } from '../../test/utils/factory';
import { setupTestDatabase } from '../../test/utils/fauna';
import { getAccessToken } from '../../test/utils/getAccessToken';

import { MSG } from '../constants/errorMsg';
import { testConfig } from '../config/config';
import { UserModel } from '../user/user.dto';
import { FolderModel } from '../folders/folders.dto';
import { FaunaModule } from '../fauna/fauna.module';

import { NotesModule } from './notes.module';
import {
  CreateNoteReqDto,
  NoteModel,
  NotesSummaryResDto,
  UpdateNoteReqDto,
} from './notes.dto';

describe('notes controller test', () => {
  let app: INestApplication;
  let user: UserModel;
  let anotherUser: UserModel;
  let folder: FolderModel;
  let accessToken: string;
  let anotherUserAccessToken: string;
  let factory: FaunaFactory;

  beforeEach(async () => {
    const { secret, childFauna } = await setupTestDatabase();
    factory = new FaunaFactory(childFauna);

    const module: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({ load: [testConfig], isGlobal: true }),
        FaunaModule.register(secret),
        NotesModule,
      ],
    }).compile();

    app = module.createNestApplication(undefined as any, { bodyParser: true });

    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
      }),
    );

    await app.init();

    user = await factory.addUser({
      email: 'test@test.test',
      password: '123123123',
      name: 'TestUser',
    });

    accessToken = getAccessToken(user);

    folder = await factory.addFolder({
      userId: user.id,
      description: 'test folder',
      name: 'test name',
    });

    anotherUser = await factory.addUser({
      email: 'user@test.test',
      name: 'user2 name',
      password: '1231231231',
    });

    anotherUserAccessToken = getAccessToken(anotherUser);
  });

  describe('POST /notes', () => {
    it(`should add note`, async () => {
      const requestData: CreateNoteReqDto = {
        folderId: folder.id,
        content: 'test note content ',
        name: 'note name',
        x: 100,
        y: 0,
        color: '#ff0000',
        height: 100,
        width: 100,
        zIndex: 199,
      };

      const { body } = await request(app.getHttpServer())
        .post(`/notes`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(201);

      const expectedNode: NoteModel = {
        ...requestData,
        id: expect.any(String),
        userId: user.id,
        folderId: folder.id,
      };

      expect(body).toEqual(expectedNode);

      const userNotes = await factory.getUserNotes(user.id);
      expect(userNotes).toHaveLength(1);

      expect(userNotes[0]).toEqual(expectedNode);
    });

    it('fails when folder does not belong to user', async () => {
      const anotherFolder = await factory.addFolder({
        description: 'test folder 2',
        name: 'folder 2 name',
        userId: anotherUser.id,
      });

      const requestData: CreateNoteReqDto = {
        folderId: anotherFolder.id,
        content: 'test note content ',
        name: 'note name',
        x: 100,
        y: 0,
        color: '#ff0000',
        height: 100,
        width: 100,
        zIndex: 199,
      };

      const { body } = await request(app.getHttpServer())
        .post(`/notes`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toBe(MSG.FOLDER_DOES_NOT_BELONG_TO_USER);
      const userNotes = await factory.getUserNotes(user.id);
      expect(userNotes).toHaveLength(0);
    });

    it('fails when required data is missing', async () => {
      const requestData: Partial<CreateNoteReqDto> = {
        content: 'test note content',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/notes`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toEqual(
        expect.arrayContaining([
          'x should not be empty',
          'x should not be empty',
          'name should not be empty',
        ]),
      );
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).post(`/notes`);

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });

  describe('GET /notes?folderId', () => {
    it('returns all notes from specified folder', async () => {
      const anotherFolder = await factory.addFolder({
        userId: user.id,
      });

      const [note1, note2, anotherFolderNote] = await Promise.all([
        factory.addNote({ userId: user.id, folderId: folder.id }),
        factory.addNote({ userId: user.id, folderId: folder.id }),
        factory.addNote({ userId: user.id, folderId: anotherFolder.id }),
      ]);

      const { body } = await request(app.getHttpServer())
        .get(`/notes?folderId=${folder.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(body.notes).toHaveLength(2);
      expect(body.notes).toEqual(expect.arrayContaining([note1, note2]));

      const { body: anotherFolderBody } = await request(app.getHttpServer())
        .get(`/notes?folderId=${anotherFolder.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(anotherFolderBody.notes).toHaveLength(1);
      expect(anotherFolderBody.notes).toEqual([anotherFolderNote]);
    });

    it('fails when folder does not belong to user', async () => {
      const anotherFolder = await factory.addFolder({
        userId: anotherUser.id,
      });

      const { body } = await request(app.getHttpServer())
        .get(`/notes?folderId=${anotherFolder.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toBe(MSG.FOLDER_DOES_NOT_BELONG_TO_USER);
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).get(
        `/notes?folderId=123`,
      );

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });

  describe('GET /notes/:noteId', () => {
    it('returns selected note', async () => {
      const [note1, note2] = await Promise.all([
        factory.addNote({ userId: user.id, folderId: folder.id }),
        factory.addNote({ userId: user.id, folderId: folder.id }),
      ]);

      const { body } = await request(app.getHttpServer())
        .get(`/notes/${note2.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(body).toEqual(note2);

      const { body: body2 } = await request(app.getHttpServer())
        .get(`/notes/${note1.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(body2).toEqual(note1);
    });

    it('fails when note does not exist', async () => {
      await Promise.all([
        factory.addNote({ userId: user.id, folderId: folder.id }),
        factory.addNote({ userId: user.id, folderId: folder.id }),
      ]);

      const { body } = await request(app.getHttpServer())
        .get(`/notes/fakeid123`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toBe(MSG.NOTE_NOT_FOUND);
    });

    it('fails when note does not belong to user', async () => {
      const [, anotherUserFolder] = await Promise.all([
        factory.addNote({ userId: user.id, folderId: folder.id }),
        factory.addNote({ userId: anotherUser.id, folderId: folder.id }),
      ]);

      const { body } = await request(app.getHttpServer())
        .get(`/notes/${anotherUserFolder.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toBe(MSG.NOTE_DOES_NOT_BELONG_TO_USER);
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).get(`/notes/123`);

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });

  describe('GET /notes/summary', () => {
    it('returns user notes summary', async () => {
      const [userFolder2, userFolder3] = await Promise.all([
        factory.addFolder({ userId: user.id }),
        factory.addFolder({ userId: user.id }),
      ]);

      await Promise.all([
        factory.addNote({ folderId: folder.id, userId: user.id }),
        factory.addNote({ folderId: folder.id, userId: user.id }),
        factory.addNote({ folderId: folder.id, userId: user.id }),
        factory.addNote({ folderId: folder.id, userId: user.id }),
        factory.addNote({ folderId: userFolder2.id, userId: user.id }),
        factory.addNote({ folderId: userFolder2.id, userId: user.id }),
      ]);

      const { body } = await request(app.getHttpServer())
        .get(`/notes/summary`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      const expectedResult: NotesSummaryResDto = {
        foldersCnt: 3,
        folders: [
          {
            id: folder.id,
            description: folder.description,
            name: folder.name,
            notesCnt: 4,
          },
          {
            id: userFolder2.id,
            description: userFolder2.description,
            name: userFolder2.name,
            notesCnt: 2,
          },
          {
            id: userFolder3.id,
            description: userFolder3.description,
            name: userFolder3.name,
            notesCnt: 0,
          },
        ],
      };

      expect(body).toEqual(expectedResult);
    });

    it('works fine when user does not have any notes yet', async () => {
      // add some notes for other users to make sure
      await Promise.all([
        factory.addNote({ userId: user.id, folderId: folder.id }),
        factory.addNote({ userId: user.id, folderId: folder.id }),
      ]);

      const { body } = await request(app.getHttpServer())
        .get(`/notes/summary`)
        .set('Authorization', `Bearer ${anotherUserAccessToken}`)
        .expect(200);

      const expectedResult: NotesSummaryResDto = {
        foldersCnt: 0,
        folders: [],
      };

      expect(body).toEqual(expectedResult);
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).get(`/notes/summary`);

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });

  describe('PATCH /notes/:noteId', () => {
    let existingNote: NoteModel;

    beforeEach(async () => {
      existingNote = await factory.addNote({
        x: 123,
        y: 123,
        name: 'name id',
        content: 'content 1',
        userId: user.id,
        folderId: folder.id,
      });
    });

    it('correctly updates note data', async () => {
      const reqData: UpdateNoteReqDto = {
        name: 'updatedName',
        content: 'updated note content',
        x: 151,
        y: 152,
      };

      const { body } = await request(app.getHttpServer())
        .patch(`/notes/${existingNote.id}`)
        .send(reqData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      const userNotes = await factory.getUserNotes(user.id);
      expect(userNotes).toHaveLength(1);
      expect(body).toEqual(userNotes[0]);
      expect(userNotes[0].content).toBe(reqData.content);
      expect(userNotes[0].name).toBe(reqData.name);
      expect(userNotes[0].x).toBe(reqData.x);
      expect(userNotes[0].y).toBe(reqData.y);
    });

    it('moves note to another folder', async () => {
      const anotherUserFolder = await factory.addFolder({
        description: 'another user folder desc',
        name: 'another user folder name',
        userId: user.id,
      });

      const notesBefore = await factory.getUserNotes(user.id);
      expect(notesBefore[0].folderId).toBe(folder.id);

      const reqData: UpdateNoteReqDto = { folderId: anotherUserFolder.id };
      await request(app.getHttpServer())
        .patch(`/notes/${existingNote.id}`)
        .send(reqData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      const userNotes = await factory.getUserNotes(user.id);
      expect(userNotes).toHaveLength(1);
      expect(userNotes[0].folderId).toBe(anotherUserFolder.id);
    });

    it('fails when folder does not belong to user', async () => {
      const anotherFolder = await factory.addFolder({
        description: 'test folder 2',
        name: 'folder 2 name',
        userId: anotherUser.id,
      });

      const reqData: UpdateNoteReqDto = {
        name: 'updatedName',
        folderId: anotherFolder.id,
      };

      const { body } = await request(app.getHttpServer())
        .patch(`/notes/${existingNote.id}`)
        .send(reqData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toBe(MSG.FOLDER_DOES_NOT_BELONG_TO_USER);
    });

    it('fails when note does not exist', async () => {
      const reqData: UpdateNoteReqDto = { name: 'updatedName' };
      const { body } = await request(app.getHttpServer())
        .patch(`/notes/4234234`)
        .set('Authorization', `Bearer ${accessToken}`)
        .send(reqData)
        .expect(400);

      expect(body.message).toBe(MSG.NOTE_NOT_FOUND);
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).patch(`/notes/123`);

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });
});

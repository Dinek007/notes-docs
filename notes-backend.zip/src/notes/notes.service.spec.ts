import { ConfigModule } from '@nestjs/config';
import { Test, TestingModule } from '@nestjs/testing';

import { FaunaFactory } from '../../test/utils/factory';
import { setupTestDatabase } from '../../test/utils/fauna';

import { MSG } from '../constants/errorMsg';
import { testConfig } from '../config/config';
import { UserModel } from '../user/user.dto';
import { FolderModel } from '../folders/folders.dto';
import { FaunaModule } from '../fauna/fauna.module';

import { NotesModule } from './notes.module';
import { NotesService } from './notes.service';

describe('NotesService test', () => {
  let user: UserModel;
  let folder: FolderModel;
  let factory: FaunaFactory;
  let service: NotesService;

  beforeEach(async () => {
    const { secret, childFauna } = await setupTestDatabase();
    factory = new FaunaFactory(childFauna);

    const module: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({ load: [testConfig], isGlobal: true }),
        FaunaModule.register(secret),
        NotesModule,
      ],
    }).compile();

    const app = module.createNestApplication(undefined as any, {
      bodyParser: true,
    });

    await app.init();

    service = app.get(NotesService);

    user = await factory.addUser({
      email: 'test@test.test',
      password: '123123123',
      name: 'TestUser',
    });

    folder = await factory.addFolder({
      userId: user.id,
      description: 'test folder',
      name: 'test name',
    });
  });

  describe('removeNote', () => {
    it('removes user note', async () => {
      const note = await factory.addNote({
        userId: user.id,
        folderId: folder.id,
      });

      const userNotesBefore = await factory.getUserNotes(user.id);
      expect(userNotesBefore).toHaveLength(1);

      await service.removeNote(user.id, note.id);

      const userNotesAfter = await factory.getUserNotes(user.id);
      expect(userNotesAfter).toHaveLength(0);
    });

    it('fails when note does not exist', async () => {
      const fakeNoteId = 'fakenote123';

      await expect(service.removeNote(user.id, fakeNoteId)).rejects.toThrow(
        MSG.NOTE_NOT_FOUND,
      );
    });

    it('fails when note does not belong to user', async () => {
      const anotherUser = await factory.addUser({
        email: 'user@test.test',
        name: 'user2 name',
        password: '1231231231',
      });

      const note = await factory.addNote({
        userId: anotherUser.id,
        folderId: folder.id,
      });

      await expect(service.removeNote(user.id, note.id)).rejects.toThrow(
        MSG.NOTE_DOES_NOT_BELONG_TO_USER,
      );
    });
  });
});

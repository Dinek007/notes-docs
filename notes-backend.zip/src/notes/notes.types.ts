import { FaunaQuery, Ref } from '../types';
import { NoteModelBase } from './notes.dto';

export type NoteDbData = Omit<NoteModelBase, 'id'> & {
  user: Ref;
  folder: Ref;
};

export type NoteQueryResult = FaunaQuery<NoteDbData>;
export type NotesQueryResult = FaunaQuery<FaunaQuery<NoteDbData>[]>;

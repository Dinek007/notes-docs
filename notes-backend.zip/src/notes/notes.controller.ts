import {
  Get,
  Post,
  Body,
  Patch,
  Query,
  Param,
  UseGuards,
  Controller,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';

import { UserId } from '../decorators/userId.decorator';
import { UserGuard } from '../auth/auth.user.strategy';

import { NotesService } from './notes.service';
import {
  NoteModel,
  CreateNoteReqDto,
  UpdateNoteReqDto,
  GetFolderNotesResDTO,
  NotesSummaryResDto,
} from './notes.dto';

@Controller('notes')
@ApiTags('Notes')
@UseGuards(UserGuard)
@ApiBearerAuth()
export class NotesController {
  constructor(private readonly notesService: NotesService) {}

  @Post()
  create(
    @UserId() userId: string,
    @Body() createNoteDto: CreateNoteReqDto,
  ): Promise<NoteModel> {
    return this.notesService.createNote(userId, createNoteDto);
  }

  @Get()
  findAll(
    @UserId() userId: string,
    @Query('folderId') folderId: string,
  ): Promise<GetFolderNotesResDTO> {
    return this.notesService.getFolderNotes(userId, folderId);
  }

  @Get('summary')
  getSummary(@UserId() userId: string): Promise<NotesSummaryResDto> {
    return this.notesService.getNotesSummary(userId);
  }

  @Get(':noteId')
  findOne(
    @UserId() userId: string,
    @Param('noteId') noteId: string,
  ): Promise<NoteModel> {
    return this.notesService.findUserNote(userId, noteId);
  }

  @Patch(':noteId')
  update(
    @Param('noteId') noteId: string,
    @UserId() userId: string,
    @Body() updateNoteDto: UpdateNoteReqDto,
  ): Promise<NoteModel> {
    return this.notesService.updateNote(noteId, userId, updateNoteDto);
  }
}

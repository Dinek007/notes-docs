import { BadRequestException, Injectable } from '@nestjs/common';
import { FaunadbService, Client, query as q } from 'nestjs-faunadb';

import { MSG } from '../constants/errorMsg';
import { AuthService } from '../auth/auth.service';
import { LoginQueryResult, UserQueryResult } from './user.types';
import { LoginReqDTO, LoginResDTO, SignupReqDTO, UserModel } from './user.dto';

@Injectable()
export class UserService {
  private faunaClient: Client;

  constructor(faunaService: FaunadbService, private authService: AuthService) {
    this.faunaClient = faunaService.getClient();
  }

  private parseUserData({ data, ref }: UserQueryResult): UserModel {
    const user: UserModel = {
      ...data,
      id: ref.id,
    };

    return user;
  }

  async getUserById(userId: string): Promise<UserModel> {
    const user = await this.faunaClient.query<UserQueryResult>(
      q.Get(q.Ref(q.Collection('Users'), userId)),
    );

    return this.parseUserData(user);
  }

  async login({ password, email }: LoginReqDTO): Promise<LoginResDTO> {
    let userInstance: string;

    try {
      const loginRes = await this.faunaClient.query<LoginQueryResult>(
        q.Login(q.Match(q.Index('user_by_email'), email), { password }),
      );

      userInstance = loginRes.instance;
    } catch (e) {
      throw new BadRequestException(MSG.USER_NOT_FOUND);
    }

    const result = await this.faunaClient.query<UserQueryResult>(
      q.Get(userInstance),
    );

    const user = this.parseUserData(result);

    const accessToken = this.authService.generateAccessToken(user.id);

    return {
      user,
      accessToken,
    };
  }

  async signUp({ email, name, password }: SignupReqDTO): Promise<LoginResDTO> {
    let existingUser!: LoginQueryResult;

    try {
      existingUser = await this.faunaClient.query<LoginQueryResult>(
        q.Get(q.Match(q.Index('user_by_email'), email)),
      );
    } catch (e) {}

    if (existingUser) {
      throw new BadRequestException(MSG.USER_ALREADY_EXISTS);
    }

    const result = await this.faunaClient.query<UserQueryResult>(
      q.Create(q.Collection('Users'), {
        credentials: { password },
        data: { email, name },
      }),
    );

    const user = this.parseUserData(result);

    const accessToken = this.authService.generateAccessToken(user.id);

    return {
      user,
      accessToken,
    };
  }
}

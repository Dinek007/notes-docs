import { FaunaQuery } from '../types';
import { UserModel } from './user.dto';

export type UserDbData = Omit<UserModel, 'id'>;
export type UserQueryResult = FaunaQuery<UserDbData>;
export type LoginQueryResult = { instance: string };

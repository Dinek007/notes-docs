import {
  IsEmail,
  IsNotEmpty,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';

export class LoginReqDTO {
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @IsNotEmpty()
  @MinLength(8)
  @MaxLength(50)
  password: string;
}

export class SignupReqDTO extends LoginReqDTO {
  @IsString()
  @IsNotEmpty()
  name: string;
}

export class UserModel {
  email: string;
  name: string;
  id: string;
}

export class LoginResDTO {
  user: UserModel;
  accessToken: string;
}

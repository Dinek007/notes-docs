import request from 'supertest';
import { ConfigModule } from '@nestjs/config';
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';

import { FaunaFactory } from '../../test/utils/factory';
import { setupTestDatabase } from '../../test/utils/fauna';

import { MSG } from '../constants/errorMsg';
import { testConfig } from '../config/config';
import { FaunaModule } from '../fauna/fauna.module';

import { UserModule } from './user.module';
import { UserDbData } from './user.types';
import { LoginReqDTO, SignupReqDTO, UserModel } from './user.dto';

describe('use controller test', () => {
  let app: INestApplication;
  let factory: FaunaFactory;

  beforeEach(async () => {
    const { secret, childFauna } = await setupTestDatabase();
    factory = new FaunaFactory(childFauna);

    const module: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({ load: [testConfig], isGlobal: true }),
        FaunaModule.register(secret),
        UserModule,
      ],
    }).compile();

    app = module.createNestApplication(undefined as any, { bodyParser: true });

    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
      }),
    );

    await app.init();
  });

  describe('POST /login', () => {
    it('should return access token', async () => {
      const existingUser: SignupReqDTO = {
        email: 'test@test.test',
        password: '123123123',
        name: 'TestUser',
      };

      await factory.addUser(existingUser);

      const loginRequest: LoginReqDTO = {
        email: existingUser.email,
        password: existingUser.password,
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/login`)
        .send(loginRequest)
        .expect(201);

      const expectedLoggedUser: UserModel = {
        email: existingUser.email,
        name: existingUser.name,
        id: expect.any(String),
      };

      expect(body).toEqual({
        user: expectedLoggedUser,
        accessToken: expect.any(String),
      });
    });

    it('fails when user does not exist', async () => {
      const loginRequest: LoginReqDTO = {
        email: 'test@test.test',
        password: '123123123',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/login`)
        .send(loginRequest)
        .expect(400);

      expect(body.message).toBe(MSG.USER_NOT_FOUND);
    });

    it('when password is invalid', async () => {
      const existingUser: SignupReqDTO = {
        email: 'test@test.test',
        password: '123123123',
        name: 'TestUser',
      };

      await factory.addUser(existingUser);

      const loginRequest: LoginReqDTO = {
        email: existingUser.email,
        password: 'wrong-password',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/login`)
        .send(loginRequest)
        .expect(400);

      expect(body.message).toBe(MSG.USER_NOT_FOUND);
    });

    it('email is invalid', async () => {
      const loginRequest: LoginReqDTO = {
        email: 'wrong-email-format@',
        password: '123123123',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/login`)
        .send(loginRequest)
        .expect(400);

      expect(body.message).toEqual(['email must be an email']);
    });

    it('password is missing', async () => {
      const loginRequest: Partial<LoginReqDTO> = {
        email: 'wrong-email-format@',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/login`)
        .send(loginRequest)
        .expect(400);

      expect(body.message).toEqual(
        expect.arrayContaining(['password should not be empty']),
      );
    });

    it('password is too short', async () => {
      const loginRequest: LoginReqDTO = {
        email: 'test@test.test',
        password: '123',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/login`)
        .send(loginRequest)
        .expect(400);

      expect(body.message).toEqual(
        expect.arrayContaining([
          'password must be longer than or equal to 8 characters',
        ]),
      );
    });
  });

  describe('POST /signUp', () => {
    it('creates user account', async () => {
      const signUpReq: SignupReqDTO = {
        email: 'test@test.test',
        password: '123123123',
        name: 'TestUser',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/signUp`)
        .send(signUpReq)
        .expect(201);

      const expectedUser: UserDbData = {
        email: signUpReq.email,
        name: signUpReq.name,
      };

      const users = await factory.getUsers();
      expect(users).toHaveLength(1);
      expect(users[0]).toEqual(expectedUser);

      const expectedUserRes: UserModel = {
        ...expectedUser,
        id: expect.any(String),
      };

      expect(body).toEqual({
        user: expectedUserRes,
        accessToken: expect.any(String),
      });
    });

    it('fails when user already exists', async () => {
      const existingUser: SignupReqDTO = {
        email: 'test@test.test',
        password: '123123123',
        name: 'TestUser',
      };

      await factory.addUser(existingUser);

      const signUpReq: SignupReqDTO = {
        email: existingUser.email,
        password: '123123123',
        name: 'TestUser',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/signUp`)
        .send(signUpReq)
        .expect(400);

      expect(body.message).toBe(MSG.USER_ALREADY_EXISTS);
    });

    it('email is invalid', async () => {
      const signUpReq: SignupReqDTO = {
        email: 'wrong-email-format@',
        password: '123123123',
        name: 'TestUser',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/signUp`)
        .send(signUpReq)
        .expect(400);

      expect(body.message).toEqual(['email must be an email']);
    });

    it('password is missing', async () => {
      const signUpReq: Partial<SignupReqDTO> = {
        email: 'wrong-email-format@',
        name: 'TestUser',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/signUp`)
        .send(signUpReq)
        .expect(400);

      expect(body.message).toEqual(
        expect.arrayContaining(['password should not be empty']),
      );
    });

    it('name is missing', async () => {
      const signUpReq: Partial<SignupReqDTO> = {
        email: 'wrong-email-format@',
        password: '123',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/signUp`)
        .send(signUpReq)
        .expect(400);

      expect(body.message).toEqual(
        expect.arrayContaining(['name should not be empty']),
      );
    });

    it('password is too short', async () => {
      const signUpReq: SignupReqDTO = {
        email: 'test@test.test',
        password: '123',
        name: 'TestUser',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/user/signUp`)
        .send(signUpReq)
        .expect(400);

      expect(body.message).toEqual(
        expect.arrayContaining([
          'password must be longer than or equal to 8 characters',
        ]),
      );
    });
  });
});

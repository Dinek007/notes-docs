import { ApiTags } from '@nestjs/swagger';
import { Body, Controller, Post } from '@nestjs/common';

import { UserService } from './user.service';
import { LoginReqDTO, LoginResDTO, SignupReqDTO } from './user.dto';

@Controller('user')
@ApiTags('User')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('login')
  async login(@Body() req: LoginReqDTO): Promise<LoginResDTO> {
    return await this.userService.login(req);
  }

  @Post('signUp')
  async signUp(@Body() req: SignupReqDTO): Promise<LoginResDTO> {
    return await this.userService.signUp(req);
  }
}

import config from '../config/config';

const { appUrl } = config();

export const emailWrapper = (content: string) => `
<table cellspacing="0" cellpadding="0"
  style="max-width: 540px; margin: 0 auto;
    font-family: 'Google Sans', sans-serif;
    text-align: center;"
  >
  <tbody>
  ${content || ''}
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" 
      style="width: 100%; 
      margin-top: 24px;
      text-align: center;
      border-top: 3px solid #b2b2b2;">
        <tr>
          <td style="padding: 36px;">
            <a href="${appUrl}"
              target="_blank"
              style="padding: 12px 36px;
                border: 3px solid #000;
                border-radius: 14px;
                font-size: 18px; color: #fff;
                font-weight: bold;
                text-decoration: none;
                display: inline-block;
                background-color: #10508b;
                color: #fff;"
            >
              Open World Of Notes
            </a>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  </tbody>
</table>
`;

export const reminderEmailBody = (reminderName: string) =>
  emailWrapper(`
  <tr>
  <td>
      <table width="100%" cellspacing="0" cellpadding="0 text-align: center;">
          <tr>
              <td>
                  <p>World of notes reminder: ${reminderName}</p>
                  <p>You can configure, cancel and add more reminders on world of notes website.</p>
              </td>
          </tr>
      </table>
  </td>
</tr>
`);

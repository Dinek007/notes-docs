import { Module } from '@nestjs/common';
import { SES } from 'aws-sdk';

import { EmailsService } from './emails.service';

@Module({
  providers: [
    EmailsService,
    {
      provide: SES,
      useClass: SES,
    },
  ],
  exports: [EmailsService],
})
export class EmailsModule {}

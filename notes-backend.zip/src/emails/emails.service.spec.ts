import AWS from 'aws-sdk';
import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';

import { EmailsService } from './emails.service';
import { EmailsModule } from './emails.module';
import { AwsSESMock } from '../../test/mocks/AwsSESMock';
import config from '../config/config';

describe('Emails service test', () => {
  let service: EmailsService;
  let module: TestingModule;

  beforeAll(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({ load: [config], isGlobal: true }),
        EmailsModule,
      ],
    })
      .overrideProvider(AWS.SES)
      .useValue(AwsSESMock)
      .compile();

    service = module.get<EmailsService>(EmailsService);
  });

  beforeEach(async () => {
    jest.clearAllMocks();
  });

  afterAll(async () => {
    await module.close();
  });

  const mockedData = {
    email: 'test@email.com',
    message: 'test-message',
    body: 'test-body',
  };

  it('should send email to user', async () => {
    await service.emailUser(
      mockedData.email,
      mockedData.message,
      mockedData.body,
    );

    expect(AwsSESMock.sendEmail).toHaveBeenCalledTimes(1);
    expect(
      AwsSESMock.sendEmail.mock.calls[0][0].Destination.ToAddresses,
    ).toEqual([mockedData.email]);
    expect(AwsSESMock.sendEmail.mock.calls[0][0].Message.Subject.Data).toEqual(
      mockedData.message,
    );
    expect(
      AwsSESMock.sendEmail.mock.calls[0][0].Message?.Body?.Html?.Data,
    ).toEqual(mockedData.body);
  });
});

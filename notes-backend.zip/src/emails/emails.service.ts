import { SES } from 'aws-sdk';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

import { Config } from '../config/config.types';

@Injectable()
export class EmailsService {
  constructor(
    private readonly ses: SES,
    private readonly config: ConfigService<Config, true>,
  ) {}

  public async emailUser(
    email: string,
    subject: string,
    body: string,
  ): Promise<void> {
    const { sender } = this.config.get('emails', {
      infer: true,
    });

    await this.ses
      .sendEmail({
        Destination: { ToAddresses: [email] },
        Message: {
          Body: {
            Html: {
              Data: body,
            },
          },
          Subject: {
            Data: subject,
          },
        },
        Source: `<${sender}>`,
      })
      .promise();
  }
}

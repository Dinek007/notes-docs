import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

import config from './config/config';
import { UserModule } from './user/user.module';
import { AuthModule } from './auth/auth.module';
import { FoldersModule } from './folders/folders.module';
import { NotesModule } from './notes/notes.module';
import { FaunaModule } from './fauna/fauna.module';
import { NotificationsModule } from './notifications/notifications.module';
import { ResetModule } from './reset/reset.module';

@Module({
  imports: [
    ConfigModule.forRoot({ load: [config], isGlobal: true }),
    FaunaModule.register(),
    UserModule,
    AuthModule,
    FoldersModule,
    NotesModule,
    NotificationsModule,
    ResetModule,
  ],
})
export class AppModule {}

import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { JwtRequest } from '../auth/auth.types';

export const UserId = createParamDecorator((_, ctx: ExecutionContext) => {
  const request = ctx.switchToHttp().getRequest<JwtRequest>();
  const userId = request.user.userId;

  return userId;
});

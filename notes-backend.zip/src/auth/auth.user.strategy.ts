import { ExtractJwt, Strategy } from 'passport-jwt';
import { PassportStrategy, AuthGuard } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { Injectable } from '@nestjs/common';

import { Config } from '../config/config.types';
import { JwtTokenPayload } from './auth.types';

export const USER_JWT_STRATEGY = 'user-jwt';

@Injectable()
export class UserJwtStrategy extends PassportStrategy(
  Strategy,
  USER_JWT_STRATEGY,
) {
  constructor(private readonly config: ConfigService<Config, true>) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: config.get('jwt', { infer: true }).secret,
    });
  }

  async validate(payload: JwtTokenPayload) {
    return payload;
  }
}

export class UserGuard extends AuthGuard(USER_JWT_STRATEGY) {}

export type JwtTokenPayload = {
  userId: string;
};

export type JwtRequest = {
  user: JwtTokenPayload;
};

import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { JwtModule, JwtModuleOptions } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';

import { Config } from '../config/config.types';

import { AuthService } from './auth.service';
import { UserJwtStrategy } from './auth.user.strategy';

@Module({
  imports: [
    PassportModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: (config: ConfigService<Config, true>) => {
        const { secret } = config.get('jwt', { infer: true });

        const options: JwtModuleOptions = {
          secret,
          signOptions: {
            expiresIn: '30d',
          },
        };

        return options;
      },
      inject: [ConfigService],
    }),
  ],
  providers: [AuthService, UserJwtStrategy],
  exports: [AuthService, UserJwtStrategy],
})
export class AuthModule {}

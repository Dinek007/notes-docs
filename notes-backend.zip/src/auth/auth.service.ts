import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

import { JwtTokenPayload } from './auth.types';

@Injectable()
export class AuthService {
  constructor(private readonly jwtService: JwtService) {}

  generateAccessToken(userId: string): string {
    const payload: JwtTokenPayload = {
      userId,
    };

    const accessToken = this.jwtService.sign(payload);

    return accessToken;
  }
}

import request from 'supertest';
import { CloudWatchEvents } from 'aws-sdk';
import { ConfigModule } from '@nestjs/config';
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';

import { FaunaFactory } from '../../test/utils/factory';
import { setupTestDatabase } from '../../test/utils/fauna';
import { getAccessToken } from '../../test/utils/getAccessToken';
import { CloudWatchEventsMock } from '../../test/mocks/CloudWatchEventsMock';

import { DeepPartial } from '../types';
import { MSG } from '../constants/errorMsg';
import { UserModel } from '../user/user.dto';
import { FaunaModule } from '../fauna/fauna.module';
import config, { testConfig } from '../config/config';
import { NoteModel } from '../notes/notes.dto';
import { FolderModel } from '../folders/folders.dto';

import {
  NotificationModel,
  NotificationType,
  CreateOneTimeNotificationDto,
  NotificationDto,
  CreateReoccurringNotificationDto,
  Days,
} from './notifications.dto';
import { TriggerParams } from './notifications.types';
import { NotificationsModule } from './notifications.module';

describe('notes controller test', () => {
  let app: INestApplication;
  let user: UserModel;
  let anotherUser: UserModel;
  let note: NoteModel;
  let folder: FolderModel;
  let accessToken: string;
  let anotherUserAccessToken: string;
  let factory: FaunaFactory;

  beforeEach(async () => {
    const { secret, childFauna } = await setupTestDatabase();
    factory = new FaunaFactory(childFauna);

    const module: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({ load: [testConfig], isGlobal: true }),
        FaunaModule.register(secret),
        NotificationsModule,
      ],
    })
      .overrideProvider(CloudWatchEvents)
      .useValue(CloudWatchEventsMock)
      .compile();

    app = module.createNestApplication(undefined as any, { bodyParser: true });

    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
      }),
    );

    jest.clearAllMocks();
    await app.init();

    user = await factory.addUser({
      email: 'test@test.test',
      password: '123123123',
      name: 'TestUser',
    });

    accessToken = getAccessToken(user);

    folder = await factory.addFolder({ userId: user.id });

    note = await factory.addNote({ userId: user.id, folderId: folder.id });

    anotherUser = await factory.addUser({
      email: 'user@test.test',
      name: 'user2 name',
      password: '1231231231',
    });

    anotherUserAccessToken = getAccessToken(anotherUser);
  });

  describe('POST /notifications/one-time', () => {
    it(`should add notification`, async () => {
      const requestData: CreateOneTimeNotificationDto = {
        noteId: note.id,
        name: 'test notification',
        triggerTime: new Date('01.01.2020 10:10').toISOString(),
      };

      const notificationsBefore = await factory.getUserNotifications(user.id);
      expect(notificationsBefore).toHaveLength(0);

      const { body } = await request(app.getHttpServer())
        .post(`/notifications/one-time`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(201);

      const expectedNotification: NotificationModel = {
        id: expect.any(String),
        name: requestData.name,
        noteId: requestData.noteId,
        type: NotificationType.OneTime,
        userId: user.id,
        expression: `cron(10 10 1 1 ? 2020)`,
        triggerTime: requestData.triggerTime,
      };

      expect(body).toEqual(expectedNotification);

      const userNotifications = await factory.getUserNotifications(user.id);
      expect(userNotifications).toHaveLength(1);

      expect(userNotifications[0]).toEqual(expectedNotification);

      expect(CloudWatchEventsMock.putRule).toHaveBeenCalledWith({
        Name: body.id,
        ScheduleExpression: expectedNotification.expression,
      });

      const expectedTriggerParams: TriggerParams = {
        notificationId: body.id,
        userEmail: user.email,
        name: body.name,
      };

      expect(CloudWatchEventsMock.putTargets).toHaveBeenCalledWith({
        Rule: body.id,
        Targets: [
          {
            Arn: config().notifications.triggerLambdaArn,
            Id: expect.any(String),
            Input: JSON.stringify(expectedTriggerParams),
          },
        ],
      });
    });

    it('fails when note does not belong to user', async () => {
      const anotherFolder = await factory.addFolder({ userId: anotherUser.id });
      const anotherNote = await factory.addNote({
        folderId: anotherFolder.id,
        userId: anotherUser.id,
      });

      const requestData: CreateOneTimeNotificationDto = {
        noteId: anotherNote.id,
        name: 'test notification',
        triggerTime: new Date('01.01.2020 10:10').toISOString(),
      };

      const notificationsBefore = await factory.getUserNotifications(user.id);
      expect(notificationsBefore).toHaveLength(0);

      const { body } = await request(app.getHttpServer())
        .post(`/notifications/one-time`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toEqual(MSG.NOTE_DOES_NOT_BELONG_TO_USER);

      const userNotifications = await factory.getUserNotifications(user.id);
      expect(userNotifications).toHaveLength(0);

      expect(CloudWatchEventsMock.putRule).not.toHaveBeenCalled();

      expect(CloudWatchEventsMock.putTargets).not.toHaveBeenCalled();
    });

    it('fails when trigger date is not valid', async () => {
      const requestData: CreateOneTimeNotificationDto = {
        noteId: note.id,
        name: 'test notification',
        triggerTime: 'invalid date',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/notifications/one-time`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toEqual([
        'triggerTime must be a valid ISO 8601 date string',
      ]);
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).post(
        `/notifications/one-time`,
      );
      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });

  describe('POST /notifications/reoccurring', () => {
    it(`should add notification`, async () => {
      const requestData: CreateReoccurringNotificationDto = {
        noteId: note.id,
        name: 'test notification',
        dayOfWeek: Days.FRIDAY,
        hours: 10,
        minutes: 20,
        timezoneOffset: 0,
      };

      const notificationsBefore = await factory.getUserNotifications(user.id);
      expect(notificationsBefore).toHaveLength(0);

      const { body } = await request(app.getHttpServer())
        .post(`/notifications/reoccurring`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(201);

      const expectedNotification: NotificationModel = {
        id: expect.any(String),
        name: requestData.name,
        noteId: requestData.noteId,
        type: NotificationType.Reoccurring,
        userId: user.id,
        expression: `cron(20 10 ? * FRI *)`,
        dayOfWeek: requestData.dayOfWeek,
        hours: requestData.hours,
        minutes: requestData.minutes,
        timezoneOffset: requestData.timezoneOffset,
      };

      expect(body).toEqual(expectedNotification);

      const userNotifications = await factory.getUserNotifications(user.id);
      expect(userNotifications).toHaveLength(1);

      expect(userNotifications[0]).toEqual(expectedNotification);

      expect(CloudWatchEventsMock.putRule).toHaveBeenCalledWith({
        Name: body.id,
        ScheduleExpression: expectedNotification.expression,
      });

      const expectedTriggerParams: TriggerParams = {
        notificationId: body.id,
        userEmail: user.email,
        name: body.name,
      };

      expect(CloudWatchEventsMock.putTargets).toHaveBeenCalledWith({
        Rule: body.id,
        Targets: [
          {
            Arn: config().notifications.triggerLambdaArn,
            Id: expect.any(String),
            Input: JSON.stringify(expectedTriggerParams),
          },
        ],
      });
    });

    it('fails when note does not belong to user', async () => {
      const anotherFolder = await factory.addFolder({ userId: anotherUser.id });
      const anotherNote = await factory.addNote({
        folderId: anotherFolder.id,
        userId: anotherUser.id,
      });

      const requestData: CreateReoccurringNotificationDto = {
        noteId: anotherNote.id,
        name: 'test notification',
        dayOfWeek: Days.FRIDAY,
        hours: 10,
        minutes: 20,
        timezoneOffset: 0,
      };

      const notificationsBefore = await factory.getUserNotifications(user.id);
      expect(notificationsBefore).toHaveLength(0);

      const { body } = await request(app.getHttpServer())
        .post(`/notifications/reoccurring`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toEqual(MSG.NOTE_DOES_NOT_BELONG_TO_USER);

      const userNotifications = await factory.getUserNotifications(user.id);
      expect(userNotifications).toHaveLength(0);

      expect(CloudWatchEventsMock.putRule).not.toHaveBeenCalled();

      expect(CloudWatchEventsMock.putTargets).not.toHaveBeenCalled();
    });

    it('fails when params are not valid', async () => {
      const requestData: CreateReoccurringNotificationDto = {
        noteId: note.id,
        name: 'test notification',
        dayOfWeek: Days.FRIDAY,
        hours: 25,
        minutes: 20,
        timezoneOffset: 0,
      };

      const { body } = await request(app.getHttpServer())
        .post(`/notifications/reoccurring`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toEqual(['hours must not be greater than 23']);
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).post(
        `/notifications/reoccurring`,
      );
      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });

  describe('GET /notifications/:noteId', () => {
    it('returns notification associated with selected note', async () => {
      const anotherNote = await factory.addNote({
        userId: user.id,
        folderId: folder.id,
      });
      await factory.addNotification({
        userId: user.id,
        noteId: anotherNote.id,
      });

      const userNotification = await factory.addNotification({
        userId: user.id,
        noteId: note.id,
      });

      const { body } = await request(app.getHttpServer())
        .get(`/notifications/${note.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      const expectedNotification: NotificationDto = {
        notification: {
          expression: userNotification.expression,
          id: userNotification.id,
          name: userNotification.name,
          noteId: note.id,
          type: userNotification.type,
          userId: user.id,
        },
      };

      expect(body).toEqual(expectedNotification);
    });

    it('works fine in case there is no notifications', async () => {
      const { body } = await request(app.getHttpServer())
        .get(`/notifications/${note.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(body.notification).toBeUndefined;
    });

    it('fails when note does not exist', async () => {
      const { body } = await request(app.getHttpServer())
        .get(`/notifications/fake-id`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toBe(MSG.NOTE_NOT_FOUND);
    });

    it('fails when note does not belong to user', async () => {
      const { body } = await request(app.getHttpServer())
        .get(`/notifications/${note.id}`)
        .set('Authorization', `Bearer ${anotherUserAccessToken}`)
        .expect(400);

      expect(body.message).toBe(MSG.NOTE_DOES_NOT_BELONG_TO_USER);
    });

    it('fails without authentication token', async () => {
      await request(app.getHttpServer())
        .get(`/notifications/${note.id}`)
        .expect(401);
    });
  });

  describe('DELETE /notifications/:notificationId', () => {
    it('removes notification from database, removes aws event rule', async () => {
      const mockTargets: DeepPartial<CloudWatchEvents.ListTargetsByRuleResponse> =
        {
          Targets: [
            {
              Id: '123',
            },
          ],
        };

      CloudWatchEventsMock.listTargetsByRule.mockReturnValue({
        promise: jest.fn().mockReturnValue(mockTargets),
      });
      const userNotification = await factory.addNotification({
        userId: user.id,
        noteId: note.id,
      });

      await request(app.getHttpServer())
        .delete(`/notifications/${userNotification.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(CloudWatchEventsMock.listTargetsByRule).toHaveBeenCalledWith({
        Rule: userNotification.id,
      });

      expect(CloudWatchEventsMock.removeTargets).toHaveBeenCalledWith({
        Rule: userNotification.id,
        Ids: ['123'],
      });

      expect(CloudWatchEventsMock.deleteRule).toHaveBeenCalledWith({
        Name: userNotification.id,
      });
    });

    it('fails when notification does not exist', async () => {
      const { body } = await request(app.getHttpServer())
        .delete(`/notifications/fake-id`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toEqual(MSG.NOTIFICATION_NOT_FOUND);
    });

    it('fails when notification does not belong to user', async () => {
      const userNotification = await factory.addNotification({
        userId: user.id,
        noteId: note.id,
      });

      const { body } = await request(app.getHttpServer())
        .delete(`/notifications/${userNotification.id}`)
        .set('Authorization', `Bearer ${anotherUserAccessToken}`)
        .expect(400);

      expect(body.message).toEqual(MSG.NOTIFICATION_DOES_NOT_BELONG_TO_USER);
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).delete(
        `/notifications/123`,
      );

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });
});

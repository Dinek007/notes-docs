import { ConfigModule } from '@nestjs/config';
import { Test, TestingModule } from '@nestjs/testing';

import { setupTestDatabase } from '../../test/utils/fauna';
import { FaunaModule } from '../fauna/fauna.module';
import { testConfig } from '../config/config';

import { Days } from './notifications.dto';
import { NotificationsModule } from './notifications.module';
import { NotificationsService } from './notifications.service';

describe('NotificationsService', () => {
  let service: NotificationsService;
  let module: TestingModule;

  /** Update to beforeEach when needed */
  beforeAll(async () => {
    const { secret } = await setupTestDatabase();

    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({ load: [testConfig], isGlobal: true }),
        NotificationsModule,
        FaunaModule.register(secret),
      ],
    }).compile();

    service = module.get<NotificationsService>(NotificationsService);
  });

  beforeEach(async () => {
    jest.clearAllMocks();
  });

  afterAll(async () => {
    await module.close();
  });

  describe('getReoccurringCronExpression', () => {
    it('adds offset properly', () => {
      const expression = service.getReoccurringCronExpression(
        Days.MONDAY,
        12,
        30,
        20,
      );

      expect(expression).toBe(`cron(50 12 ? * ${Days.MONDAY} *)`);
    });

    it('with negative offset', () => {
      const expression = service.getReoccurringCronExpression(
        Days.MONDAY,
        12,
        30,
        -20,
      );

      expect(expression).toBe(`cron(10 12 ? * ${Days.MONDAY} *)`);
    });

    it('adds hours when needed', () => {
      const expression = service.getReoccurringCronExpression(
        Days.MONDAY,
        12,
        50,
        140,
      );

      expect(expression).toBe(`cron(10 15 ? * ${Days.MONDAY} *)`);
    });

    it('subtract hours when needed', () => {
      const expression = service.getReoccurringCronExpression(
        Days.MONDAY,
        18,
        10,
        -150,
      );

      expect(expression).toBe(`cron(40 15 ? * ${Days.MONDAY} *)`);
    });

    it('adds days when needed', () => {
      const expression = service.getReoccurringCronExpression(
        Days.MONDAY,
        23,
        50,
        140,
      );

      expect(expression).toBe(`cron(10 2 ? * ${Days.TUESDAY} *)`);
    });

    it('subtract days when needed', () => {
      const expression = service.getReoccurringCronExpression(
        Days.TUESDAY,
        0,
        10,
        -140,
      );

      expect(expression).toBe(`cron(50 21 ? * ${Days.MONDAY} *)`);
    });

    it('takes days from another week if needed', () => {
      const expression = service.getReoccurringCronExpression(
        Days.SUNDAY,
        23,
        0,
        180,
      );

      expect(expression).toBe(`cron(0 2 ? * ${Days.MONDAY} *)`);
    });

    it('takes days from previous week if needed', () => {
      const expression = service.getReoccurringCronExpression(
        Days.MONDAY,
        1,
        0,
        -180,
      );

      expect(expression).toBe(`cron(0 22 ? * ${Days.SUNDAY} *)`);
    });
  });
});

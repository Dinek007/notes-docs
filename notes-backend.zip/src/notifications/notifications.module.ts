import { Module } from '@nestjs/common';
import { CloudWatchEvents } from 'aws-sdk';

import { NotesModule } from '../notes/notes.module';
import { UserModule } from '../user/user.module';
import { EmailsModule } from '../emails/emails.module';

import { NotificationsService } from './notifications.service';
import { NotificationsController } from './notifications.controller';

@Module({
  imports: [NotesModule, UserModule, EmailsModule],
  controllers: [NotificationsController],
  providers: [
    NotificationsService,
    { provide: CloudWatchEvents, useClass: CloudWatchEvents },
  ],
  exports: [NotificationsService],
})
export class NotificationsModule {}

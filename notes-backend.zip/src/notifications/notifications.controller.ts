import {
  Controller,
  Post,
  Body,
  UseGuards,
  Get,
  Param,
  Delete,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { UserGuard } from '../auth/auth.user.strategy';

import { UserId } from '../decorators/userId.decorator';
import {
  NotificationModel,
  CreateOneTimeNotificationDto,
  NotificationDto,
  CreateReoccurringNotificationDto,
} from './notifications.dto';
import { NotificationsService } from './notifications.service';

@Controller('notifications')
@ApiTags('notifications')
@UseGuards(UserGuard)
@ApiBearerAuth()
export class NotificationsController {
  constructor(private readonly notificationsService: NotificationsService) {}

  @Post('one-time')
  create(
    @Body() createNotificationDto: CreateOneTimeNotificationDto,
    @UserId() userId: string,
  ): Promise<NotificationModel> {
    return this.notificationsService.createOneTime(
      createNotificationDto,
      userId,
    );
  }

  @Post('reoccurring')
  createReoccurring(
    @Body() createNotificationDto: CreateReoccurringNotificationDto,
    @UserId() userId: string,
  ): Promise<NotificationModel> {
    return this.notificationsService.createReoccurring(
      createNotificationDto,
      userId,
    );
  }

  @Get(':noteId')
  findOne(
    @Param('noteId') noteId: string,
    @UserId() userId: string,
  ): Promise<NotificationDto> {
    return this.notificationsService.findNoteNotification(userId, noteId);
  }

  @Delete(':notificationId')
  remove(
    @Param('notificationId') notificationId: string,
    @UserId() userId: string,
  ) {
    return this.notificationsService.removeNotification(userId, notificationId);
  }
}

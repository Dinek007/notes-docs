import { FaunaQuery, Ref } from '../types';
import { NotificationModelBase } from './notifications.dto';

export type NotificationDbData = Omit<NotificationModelBase, 'id'> & {
  user: Ref;
  note: Ref;
};

export type NotificationQueryResult = FaunaQuery<NotificationDbData>;
export type NotificationsQueryResult = FaunaQuery<
  FaunaQuery<NotificationDbData>[]
>;

export type TriggerParams = {
  notificationId: string;
  userEmail: string;
  name: string;
};

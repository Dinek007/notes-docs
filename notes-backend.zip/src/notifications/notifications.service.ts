import { CloudWatchEvents } from 'aws-sdk';
import { BadRequestException, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { v4 as uuidV4 } from 'uuid';
import { FaunadbService, Client, query as q } from 'nestjs-faunadb';
import {
  CreateOneTimeNotificationDto,
  CreateReoccurringNotificationDto,
  Days,
  NotificationDto,
  NotificationModel,
  NotificationType,
} from './notifications.dto';
import { Config } from '../config/config.types';
import {
  NotificationDbData,
  NotificationQueryResult,
  NotificationsQueryResult,
  TriggerParams,
} from './notifications.types';
import { Ref } from '../types';
import { NotesService } from '../notes/notes.service';
import { EmailsService } from '../emails/emails.service';
import { reminderEmailBody } from '../emails/email.templates';
import { UserService } from '../user/user.service';
import { MSG } from '../constants/errorMsg';

@Injectable()
export class NotificationsService {
  private faunaClient: Client;

  constructor(
    private readonly cloudwatchEvents: CloudWatchEvents,
    private readonly emailsService: EmailsService,
    private readonly userService: UserService,
    private readonly configService: ConfigService<Config, true>,
    private readonly notesService: NotesService,
    faunaService: FaunadbService,
  ) {
    this.faunaClient = faunaService.getClient();
  }

  private parseNotificationData({
    ref,
    data,
  }: NotificationQueryResult): NotificationModel {
    const { user, note, ...filteredData } = data;

    return {
      id: ref.id,
      userId: user.id,
      noteId: note.id,
      ...filteredData,
    };
  }

  private async scheduleNotification(
    userId: string,
    notification: NotificationModel,
  ) {
    const user = await this.userService.getUserById(userId);

    const ruleName = notification.id;

    await this.cloudwatchEvents
      .putRule({
        Name: ruleName,
        ScheduleExpression: notification.expression,
      })
      .promise();

    const triggerParams: TriggerParams = {
      notificationId: notification.id,
      userEmail: user.email,
      name: notification.name,
    };

    await this.cloudwatchEvents
      .putTargets({
        Rule: ruleName,
        Targets: [
          {
            Arn: this.configService.get('notifications', { infer: true })
              .triggerLambdaArn,
            Id: uuidV4(),
            Input: JSON.stringify(triggerParams),
          },
        ],
      })
      .promise();
  }

  private getOneTimeScheduleCronExpression(date: string): string {
    const parsedDate = new Date(date);

    const minutes = parsedDate.getMinutes();
    const hours = parsedDate.getHours();
    const day = parsedDate.getDate();
    const month = parsedDate.getMonth();
    const year = parsedDate.getFullYear();

    return `cron(${minutes} ${hours} ${day} ${month + 1} ? ${year})`;
  }

  async createOneTime(
    dto: CreateOneTimeNotificationDto,
    userId: string,
  ): Promise<NotificationModel> {
    const { name, noteId, triggerTime } = dto;
    await this.notesService.findUserNote(userId, noteId);

    const cronExpression = this.getOneTimeScheduleCronExpression(triggerTime);

    const notificationData: { data: NotificationDbData } = {
      data: {
        name,
        triggerTime,
        expression: cronExpression,
        type: NotificationType.OneTime,
        user: q.Ref(q.Collection('Users'), userId) as Ref,
        note: q.Ref(q.Collection('Notes'), noteId) as Ref,
      },
    };

    const addedNotification =
      await this.faunaClient.query<NotificationQueryResult>(
        q.Create(q.Collection('Notifications'), notificationData),
      );

    const parsedNotification = this.parseNotificationData(addedNotification);

    await this.scheduleNotification(userId, parsedNotification);

    return parsedNotification;
  }

  getReoccurringCronExpression(
    dayOfWeek: Days,
    hours: number,
    minutes: number,
    timezoneOffset: number,
  ): string {
    const offsetSign = Math.sign(timezoneOffset);

    let offsetHours = offsetSign * Math.floor(Math.abs(timezoneOffset) / 60);
    let offsetMinutes =
      offsetSign * (Math.abs(timezoneOffset) - Math.abs(offsetHours * 60));

    let offsetDays = 0;

    if (minutes + offsetMinutes < 0) {
      offsetHours--;
      offsetMinutes = 60 + offsetMinutes;
    } else if (minutes + offsetMinutes > 60) {
      offsetHours++;
      offsetMinutes = offsetMinutes - 60;
    }

    if (hours + offsetHours < 0) {
      offsetDays--;
      offsetHours = 24 + offsetHours;
    } else if (hours + offsetHours > 23) {
      offsetDays++;
      offsetHours = offsetHours - 24;
    }

    const getAdjustedDay = () => {
      const dayValues = Object.values(Days);
      let adjustedIndex =
        dayValues.findIndex((d) => d === dayOfWeek) + offsetDays;

      if (adjustedIndex < 0) {
        adjustedIndex = 7 + adjustedIndex;
      } else if (adjustedIndex > 6) {
        adjustedIndex = 7 - adjustedIndex;
      }

      return dayValues[adjustedIndex];
    };

    return `cron(${minutes + offsetMinutes} ${
      hours + offsetHours
    } ? * ${getAdjustedDay()} *)`;
  }

  async createReoccurring(
    dto: CreateReoccurringNotificationDto,
    userId: string,
  ): Promise<NotificationModel> {
    const { noteId, name, dayOfWeek, hours, minutes, timezoneOffset } = dto;

    await this.notesService.findUserNote(userId, noteId);

    const cronExpression = this.getReoccurringCronExpression(
      dayOfWeek,
      hours,
      minutes,
      timezoneOffset,
    );

    const notificationData: { data: NotificationDbData } = {
      data: {
        name,
        hours,
        minutes,
        dayOfWeek,
        timezoneOffset,
        expression: cronExpression,
        type: NotificationType.Reoccurring,
        user: q.Ref(q.Collection('Users'), userId) as Ref,
        note: q.Ref(q.Collection('Notes'), noteId) as Ref,
      },
    };

    const addedNotification =
      await this.faunaClient.query<NotificationQueryResult>(
        q.Create(q.Collection('Notifications'), notificationData),
      );

    const parsedNotification = this.parseNotificationData(addedNotification);

    await this.scheduleNotification(userId, parsedNotification);

    return parsedNotification;
  }

  async findUserNotification(
    userId: string,
    notificationId: string,
  ): Promise<NotificationModel> {
    let notificationRes: NotificationQueryResult;

    try {
      notificationRes = await this.faunaClient.query<NotificationQueryResult>(
        q.Get(q.Match(q.Index('notification_by_id'), notificationId)),
      );
    } catch (e) {
      throw new BadRequestException(MSG.NOTIFICATION_NOT_FOUND);
    }

    if (notificationRes.data.user.id !== userId) {
      throw new BadRequestException(MSG.NOTIFICATION_DOES_NOT_BELONG_TO_USER);
    }

    const parsedRes = this.parseNotificationData(notificationRes);

    return parsedRes;
  }

  async findNoteNotifications(
    userId: string,
    noteId: string,
  ): Promise<NotificationModel[]> {
    await this.notesService.findUserNote(userId, noteId);

    const { data: notifications } =
      await this.faunaClient.query<NotificationsQueryResult>(
        q.Map(
          q.Paginate(
            q.Match(
              q.Index('notifications_by_note'),
              q.Ref(q.Collection('Notes'), noteId),
            ),
          ),
          q.Lambda('ref', q.Get(q.Var('ref'))),
        ),
      );

    return notifications.map((notification) =>
      this.parseNotificationData(notification),
    );
  }

  async findNoteNotification(
    userId: string,
    noteId: string,
  ): Promise<NotificationDto> {
    const notifications = await this.findNoteNotifications(userId, noteId);

    if (!notifications.length) {
      return { notification: undefined };
    }

    return {
      notification: notifications[0],
    };
  }

  async removeNotification(userId: string, notificationId: string) {
    await this.findUserNotification(userId, notificationId);

    const { Targets } = await this.cloudwatchEvents
      .listTargetsByRule({ Rule: notificationId })
      .promise();

    const Ids = Targets?.map((target) => target.Id) ?? [];

    await this.cloudwatchEvents
      .removeTargets({
        Rule: notificationId,
        Ids,
      })
      .promise();

    await this.cloudwatchEvents.deleteRule({ Name: notificationId }).promise();

    await this.faunaClient.query<NotificationsQueryResult>(
      q.Delete(q.Ref(q.Collection('Notifications'), notificationId)),
    );
  }

  async triggerNotification(params: TriggerParams) {
    console.log('trigger params', params);

    await this.emailsService.emailUser(
      params.userEmail,
      `reminder: ${params.name}`,
      reminderEmailBody(params.name),
    );
  }
}

import { ApiProperty, PickType } from '@nestjs/swagger';
import {
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  Min,
} from 'class-validator';

export enum NotificationType {
  Reoccurring = 'reoccurring',
  OneTime = 'oneTime',
}

export enum Days {
  SUNDAY = 'SUN',
  MONDAY = 'MON',
  TUESDAY = 'TUE',
  WEDNESDAY = 'WED',
  THURSDAY = 'THU',
  FRIDAY = 'FRI',
  SATURDAY = 'SAT',
}

export class NotificationModelBase {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  name: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  expression: string;

  @IsEnum(NotificationType)
  @IsNotEmpty()
  @ApiProperty()
  type: NotificationType;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  triggerTime?: string;

  @IsEnum(Days)
  @IsOptional()
  dayOfWeek?: Days;

  @IsInt()
  @IsOptional()
  @Min(0)
  @Max(23)
  hours?: number;

  @IsInt()
  @IsOptional()
  @Min(0)
  @Max(59)
  minutes?: number;

  @IsOptional()
  @IsInt()
  timezoneOffset?: number;
}

export class NotificationModel extends NotificationModelBase {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  userId: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  noteId: string;

  @ApiProperty()
  id: string;
}

export class NotificationDto {
  @IsOptional()
  notification?: NotificationModel;
}

export class CreateOneTimeNotificationDto extends PickType(NotificationModel, [
  'noteId',
  'name',
]) {
  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  triggerTime: string;
}

export class CreateReoccurringNotificationDto extends PickType(
  NotificationModel,
  ['noteId', 'name'],
) {
  @IsEnum(Days)
  @IsNotEmpty()
  dayOfWeek: Days;

  @IsInt()
  @IsNotEmpty()
  @Min(0)
  @Max(23)
  hours: number;

  @IsInt()
  @IsNotEmpty()
  @Min(0)
  @Max(59)
  minutes: number;

  @IsNotEmpty()
  @IsInt()
  timezoneOffset: number;
}

import { Module } from '@nestjs/common';

import { NotesModule } from '../notes/notes.module';
import { FoldersModule } from '../folders/folders.module';
import { NotificationsModule } from '../notifications/notifications.module';

import { ResetService } from './reset.service';
import { ResetController } from './reset.controller';

@Module({
  imports: [NotesModule, NotificationsModule, FoldersModule],
  controllers: [ResetController],
  providers: [ResetService],
})
export class ResetModule {}

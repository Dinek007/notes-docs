import request from 'supertest';
import { CloudWatchEvents } from 'aws-sdk';
import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import { INestApplication, ValidationPipe } from '@nestjs/common';

import { FaunaFactory } from '../../test/utils/factory';
import { setupTestDatabase } from '../../test/utils/fauna';
import { getAccessToken } from '../../test/utils/getAccessToken';
import { CloudWatchEventsMock } from '../../test/mocks/CloudWatchEventsMock';

import { DeepPartial } from '../types';
import { testConfig } from '../config/config';
import { UserModel } from '../user/user.dto';
import { FaunaModule } from '../fauna/fauna.module';
import { NotificationModel } from '../notifications/notifications.dto';

import { ResetModule } from './reset.module';

describe('ResetController', () => {
  let app: INestApplication;
  let factory: FaunaFactory;
  let user: UserModel;
  let accessToken: string;

  beforeEach(async () => {
    const { secret, childFauna } = await setupTestDatabase();
    factory = new FaunaFactory(childFauna);

    const module: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({ load: [testConfig], isGlobal: true }),
        FaunaModule.register(secret),
        ResetModule,
      ],
    })
      .overrideProvider(CloudWatchEvents)
      .useValue(CloudWatchEventsMock)
      .compile();

    app = module.createNestApplication(undefined as any, { bodyParser: true });

    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
      }),
    );

    jest.clearAllMocks();
    await app.init();

    user = await factory.addUser({
      email: 'test@test.test',
      password: '123123123',
      name: 'TestUser',
    });

    accessToken = getAccessToken(user);
  });

  describe('DELETE /reset/note/noteId', () => {
    it('removes note with its containing notifications', async () => {
      const mockTargets: DeepPartial<CloudWatchEvents.ListTargetsByRuleResponse> =
        { Targets: [{ Id: '123' }] };

      CloudWatchEventsMock.listTargetsByRule.mockReturnValue({
        promise: jest.fn().mockReturnValue(mockTargets),
      });

      const folder = await factory.addFolder({
        userId: user.id,
      });
      const note = await factory.addNote({
        userId: user.id,
        folderId: folder.id,
      });

      const notifications = await Promise.all(
        Array.from({ length: 2 }).map(() => {
          return factory.addNotification({
            noteId: note.id,
            userId: user.id,
          });
        }),
      );

      await request(app.getHttpServer())
        .delete(`/reset/note/${note.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      const userNotesAfter = await factory.getUserNotes(user.id);
      const notificationsAfter = await factory.getUserNotifications(user.id);

      expect(userNotesAfter).toHaveLength(0);
      expect(notificationsAfter).toHaveLength(0);

      expect(CloudWatchEventsMock.deleteRule).toHaveBeenCalledWith({
        Name: notifications[0].id,
      });
      expect(CloudWatchEventsMock.deleteRule).toHaveBeenCalledWith({
        Name: notifications[1].id,
      });
    });
  });

  describe('DELETE /reset/folder/folderId', () => {
    it('removes folder with all notes and notifications', async () => {
      const folder = await factory.addFolder({
        userId: user.id,
      });

      const createNoteWithNotification = async (index: number) => {
        const note = await factory.addNote({
          userId: user.id,
          folderId: folder.id,
        });

        let notification: undefined | NotificationModel;

        if (index % 2 === 0) {
          notification = await factory.addNotification({
            noteId: note.id,
            userId: user.id,
          });
        }

        return { note, notification };
      };

      await Promise.all(
        Array.from({ length: 11 }).map((_, index) => {
          return createNoteWithNotification(index);
        }),
      );

      const notificationsBefore = await factory.getUserNotifications(user.id);

      await request(app.getHttpServer())
        .delete(`/reset/folder/${folder.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      const userNotesAfter = await factory.getUserNotes(user.id);
      const notificationsAfter = await factory.getUserNotifications(user.id);
      const foldersAfter = await factory.getUserFolders(user.id);

      expect(userNotesAfter).toHaveLength(0);
      expect(notificationsAfter).toHaveLength(0);
      expect(foldersAfter).toHaveLength(0);

      expect(CloudWatchEventsMock.deleteRule).toHaveBeenCalledTimes(
        notificationsBefore.length,
      );
    });
  });
});

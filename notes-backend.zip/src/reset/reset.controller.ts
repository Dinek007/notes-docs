import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Controller, Param, Delete, UseGuards } from '@nestjs/common';
import { UserId } from '../decorators/userId.decorator';
import { UserGuard } from '../auth/auth.user.strategy';
import { ResetService } from './reset.service';

@ApiBearerAuth()
@ApiTags('Reset')
@UseGuards(UserGuard)
@Controller('reset')
export class ResetController {
  constructor(private readonly resetService: ResetService) {}

  @Delete('note/:noteId')
  removeNote(@Param('noteId') noteId: string, @UserId() userId: string) {
    return this.resetService.removeNote(userId, noteId);
  }

  @Delete('folder/:folderId')
  removeFolder(@Param('folderId') folderId: string, @UserId() userId: string) {
    return this.resetService.removeFolder(userId, folderId);
  }
}

import { Injectable } from '@nestjs/common';
import { NotificationsService } from '../notifications/notifications.service';
import { FoldersService } from '../folders/folders.service';
import { NotesService } from '../notes/notes.service';

const REMOVE_FOLDER_NOTES_BATCH_SIZE = 5;

@Injectable()
export class ResetService {
  constructor(
    private readonly notesService: NotesService,
    private readonly foldersService: FoldersService,
    private readonly notificationsService: NotificationsService,
  ) {}

  async removeNote(userId: string, noteId: string) {
    const notifications = await this.notificationsService.findNoteNotifications(
      userId,
      noteId,
    );

    await Promise.all(
      notifications.map(({ id }) => {
        return this.notificationsService.removeNotification(userId, id);
      }),
    );

    await this.notesService.removeNote(userId, noteId);
  }

  async removeFolder(userId: string, folderId: string) {
    const { notes } = await this.notesService.getFolderNotes(userId, folderId);

    for (let i = 0; i < notes.length; i += REMOVE_FOLDER_NOTES_BATCH_SIZE) {
      const notesBatch = notes.slice(i, i + REMOVE_FOLDER_NOTES_BATCH_SIZE);

      await Promise.all(
        notesBatch.map((note) => this.removeNote(userId, note.id)),
      );
    }

    await this.foldersService.removeUserFolder(userId, folderId);
  }
}

import { Context, APIGatewayProxyEvent, Callback } from 'aws-lambda';
import awsServerlessExpress from '@vendia/serverless-express';

import { createApp } from './createApp';
import { getNotificationsService } from './helpers/getNotificationsService';
import { TriggerParams } from './notifications/notifications.types';

let appServer: ReturnType<typeof awsServerlessExpress>;

export const app = async (
  event: APIGatewayProxyEvent,
  context: Context,
  callback: Callback<any>,
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  if (!appServer) {
    const nestApp = await createApp({ cors: true });

    await nestApp.init();
    const app = nestApp.getHttpAdapter().getInstance();
    appServer = awsServerlessExpress({ app });
  }

  const server = await appServer(event, context, callback);

  return server;
};

export const triggerNotification = async (event: TriggerParams) => {
  const notificationsService = await getNotificationsService();

  await notificationsService.triggerNotification(event);
};

import { ClientConfig } from 'nestjs-faunadb';

type NotificationsConfig = {
  triggerLambdaArn: string;
};

export type Config = {
  jwt: {
    secret: string;
  };
  emails: {
    sender: string;
  };
  db: ClientConfig;
  notifications: NotificationsConfig;
  appUrl: string;
};

// import { ClientConfig } from 'nestjs-faunadb';
import { ClientConfig } from 'nestjs-faunadb';
import { Config } from './config.types';

export const mockJwtSecret = 'secret-for-tests';

const getConfig = (): Config => {
  return {
    jwt: {
      secret: process.env.JWT_SECRET ?? '',
    },
    db: {
      secret: process.env.FAUNA_ADMIN_KEY ?? '',
      domain: process.env.FAUNADB_DOMAIN ?? undefined,
      port: Number(process.env.FAUNADB_PORT) ?? undefined,
      scheme: (process.env.FAUNADB_SCHEME as ClientConfig['scheme']) || 'http',
    },
    emails: {
      sender: 'worldofnotesreminder@gmail.com',
    },
    notifications: {
      triggerLambdaArn: process.env.TRIGGER_LAMBDA_ARN ?? '',
    },
    appUrl: 'https://world-of-notes-app.netlify.app',
  };
};

export const testConfig = (): Config => ({
  ...getConfig(),
  jwt: {
    secret: mockJwtSecret,
  },
});

export default getConfig;

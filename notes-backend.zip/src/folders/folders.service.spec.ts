import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';

import { FaunaFactory } from '../../test/utils/factory';
import { setupTestDatabase } from '../../test/utils/fauna';

import { MSG } from '../constants/errorMsg';
import { testConfig } from '../config/config';
import { UserModel } from '../user/user.dto';
import { FaunaModule } from '../fauna/fauna.module';

import { FoldersModule } from './folders.module';
import { FoldersService } from './folders.service';

describe('folders controller test', () => {
  let factory: FaunaFactory;
  let user: UserModel;
  let service: FoldersService;

  beforeEach(async () => {
    const { secret, childFauna } = await setupTestDatabase();
    factory = new FaunaFactory(childFauna);

    const module: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({ load: [testConfig], isGlobal: true }),
        FaunaModule.register(secret),
        FoldersModule,
      ],
    }).compile();

    const app = module.createNestApplication(undefined as any, {
      bodyParser: true,
    });

    await app.init();

    service = app.get(FoldersService);

    user = await factory.addUser({
      email: 'test@test.test',
      password: '123123123',
      name: 'TestUser',
    });
  });

  describe('removeUserFolder', () => {
    it(`should delete folder`, async () => {
      const userFolder = await factory.addFolder({
        name: 'folder1',
        description: 'folder1 desc',
        userId: user.id,
      });

      const userFoldersBefore = await factory.getUserFolders(user.id);
      expect(userFoldersBefore).toHaveLength(1);

      await service.removeUserFolder(user.id, userFolder.id);

      const userFolders = await factory.getUserFolders(user.id);
      expect(userFolders).toHaveLength(0);
    });

    it(`fails when folder does not belong to user`, async () => {
      const otherUser = await factory.addUser({
        email: 'test2@test.test',
        password: '123123123',
        name: 'TestUser2',
      });

      const folder1 = await factory.addFolder({
        name: 'folder1',
        description: 'folder1 desc',
        userId: otherUser.id,
      });

      const otherUserFoldersBefore = await factory.getUserFolders(otherUser.id);

      await expect(
        service.removeUserFolder(user.id, folder1.id),
      ).rejects.toThrow(MSG.FOLDER_DOES_NOT_BELONG_TO_USER);

      const userFolders = await factory.getUserFolders(otherUser.id);
      expect(userFolders.length).toBe(otherUserFoldersBefore.length);
    });
  });
});

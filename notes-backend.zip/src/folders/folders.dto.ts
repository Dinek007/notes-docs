import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class CreateFolderDto {
  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  description: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty()
  name: string;
}

export class UpdateFolderDto extends PartialType(CreateFolderDto) {}

export class GetAllUserFoldersResDTO {
  folders: FolderModel[];
}

export class FolderModel {
  description: string;
  name: string;
  id: string;
}

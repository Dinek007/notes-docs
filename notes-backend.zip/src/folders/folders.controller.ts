import {
  Get,
  Post,
  Body,
  Patch,
  Param,
  UseGuards,
  Controller,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';

import { UserId } from '../decorators/userId.decorator';
import { UserGuard } from '../auth/auth.user.strategy';

import {
  FolderModel,
  CreateFolderDto,
  UpdateFolderDto,
  GetAllUserFoldersResDTO,
} from './folders.dto';
import { FoldersService } from './folders.service';

@Controller('folders')
@ApiTags('Folders')
@UseGuards(UserGuard)
@ApiBearerAuth()
export class FoldersController {
  constructor(private readonly foldersService: FoldersService) {}

  @Post()
  create(
    @UserId() userId: string,
    @Body() createFolderDto: CreateFolderDto,
  ): Promise<FolderModel> {
    return this.foldersService.create(userId, createFolderDto);
  }

  @Get()
  getUserFolders(@UserId() userId: string): Promise<GetAllUserFoldersResDTO> {
    return this.foldersService.getUserFolders(userId);
  }

  @Get(':folderId')
  findUserFolder(
    @Param('folderId') folderId: string,
    @UserId() userId: string,
  ): Promise<FolderModel> {
    return this.foldersService.findUserFolder(userId, folderId);
  }

  @Patch(':folderId')
  updateUserFolder(
    @Param('folderId') folderId: string,
    @Body() updateFolderDto: UpdateFolderDto,
    @UserId() userId: string,
  ): Promise<FolderModel> {
    return this.foldersService.updateUserFolder(
      userId,
      folderId,
      updateFolderDto,
    );
  }
}

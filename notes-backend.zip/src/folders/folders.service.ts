import { BadRequestException, Injectable } from '@nestjs/common';
import { FaunadbService, Client, query as q } from 'nestjs-faunadb';

import { MSG } from '../constants/errorMsg';

import {
  FolderModel,
  UpdateFolderDto,
  CreateFolderDto,
  GetAllUserFoldersResDTO,
} from './folders.dto';
import { FolderQueryResult, FoldersQueryResult } from './folders.types';

@Injectable()
export class FoldersService {
  private faunaClient: Client;

  constructor(faunaService: FaunadbService) {
    this.faunaClient = faunaService.getClient();
  }

  private parseFolderData({ ref, data }: FolderQueryResult): FolderModel {
    const { user, ...filteredData } = data;

    return {
      id: ref.id,
      ...filteredData,
    };
  }

  async create(
    userId: string,
    createFolderDto: CreateFolderDto,
  ): Promise<FolderModel> {
    const { name, description } = createFolderDto;

    let existingFolder!: FolderQueryResult;

    try {
      existingFolder = await this.faunaClient.query<FolderQueryResult>(
        q.Get(
          q.Match(
            q.Index('user_folder_by_name'),
            q.Ref(q.Collection('Users'), userId),
            name,
          ),
        ),
      );
    } catch (e) {}

    if (existingFolder) {
      throw new BadRequestException(MSG.FOLDER_NAME_DUPLICATE);
    }

    const folder = {
      data: {
        name,
        description,
        user: q.Ref(q.Collection('Users'), userId),
      },
    };

    const folderRes = await this.faunaClient.query<FolderQueryResult>(
      q.Create(q.Collection('Folders'), folder),
    );

    return this.parseFolderData(folderRes);
  }

  async getUserFolders(userId: string): Promise<GetAllUserFoldersResDTO> {
    const { data: foldersData } =
      await this.faunaClient.query<FoldersQueryResult>(
        q.Map(
          q.Paginate(
            q.Match(
              q.Index('folders_by_user'),
              q.Ref(q.Collection('Users'), userId),
            ),
          ),
          q.Lambda('ref', q.Get(q.Var('ref'))),
        ),
      );

    const parsedFoldersData: FolderModel[] = foldersData.map(
      this.parseFolderData,
    );

    return {
      folders: parsedFoldersData,
    };
  }

  async findUserFolder(userId: string, id: string): Promise<FolderModel> {
    const folderRes = await this.faunaClient.query<FolderQueryResult>(
      q.Get(q.Match(q.Index('folder_by_id'), id)),
    );

    if (folderRes.data.user.id !== userId) {
      throw new BadRequestException(MSG.FOLDER_DOES_NOT_BELONG_TO_USER);
    }

    const parsedFolder = this.parseFolderData(folderRes);

    return parsedFolder;
  }

  async updateUserFolder(
    userId: string,
    folderId: string,
    updateFolderDto: UpdateFolderDto,
  ): Promise<FolderModel> {
    const existingFolder = await this.findUserFolder(userId, folderId);

    const { id, ...existingFolderData } = existingFolder;

    const updateData = {
      data: {
        ...existingFolderData,
        ...updateFolderDto,
      },
    };

    const updated = await this.faunaClient.query<FolderQueryResult>(
      q.Update(q.Ref(q.Collection('Folders'), id), updateData),
    );

    return this.parseFolderData(updated);
  }

  async removeUserFolder(userId: string, folderId: string): Promise<void> {
    await this.findUserFolder(userId, folderId);

    await this.faunaClient.query<FolderQueryResult>(
      q.Delete(q.Ref(q.Collection('Folders'), folderId)),
    );
  }
}

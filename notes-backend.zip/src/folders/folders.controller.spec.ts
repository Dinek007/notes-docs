import request from 'supertest';
import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import { INestApplication, ValidationPipe } from '@nestjs/common';

import { FaunaFactory } from '../../test/utils/factory';
import { setupTestDatabase } from '../../test/utils/fauna';
import { getAccessToken } from '../../test/utils/getAccessToken';

import { MSG } from '../constants/errorMsg';
import { testConfig } from '../config/config';
import { UserModel } from '../user/user.dto';
import { FaunaModule } from '../fauna/fauna.module';

import {
  FolderModel,
  CreateFolderDto,
  UpdateFolderDto,
  GetAllUserFoldersResDTO,
} from './folders.dto';
import { FoldersModule } from './folders.module';

describe('folders controller test', () => {
  let app: INestApplication;
  let factory: FaunaFactory;
  let user: UserModel;
  let accessToken: string;

  beforeEach(async () => {
    const { secret, childFauna } = await setupTestDatabase();
    factory = new FaunaFactory(childFauna);

    const module: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({ load: [testConfig], isGlobal: true }),
        FaunaModule.register(secret),
        FoldersModule,
      ],
    }).compile();

    app = module.createNestApplication(undefined as any, { bodyParser: true });

    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
      }),
    );

    await app.init();

    user = await factory.addUser({
      email: 'test@test.test',
      password: '123123123',
      name: 'TestUser',
    });

    accessToken = getAccessToken(user);
  });

  describe('GET /folders', () => {
    it(`should return all user's folders`, async () => {
      const otherUser = await await factory.addUser({
        email: 'test2@test.test',
        password: '123123123',
        name: 'TestUser2',
      });

      const [folder1, folder2] = await Promise.all([
        factory.addFolder({
          name: 'folder1',
          description: 'folder1 desc',
          userId: user.id,
        }),
        factory.addFolder({
          name: 'folder2',
          description: 'folder2 desc',
          userId: user.id,
        }),
        factory.addFolder({
          name: 'folder3',
          description: 'folder3 desc',
          userId: otherUser.id,
        }),
      ]);

      const { body } = await request(app.getHttpServer())
        .get(`/folders`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(body.folders).toHaveLength(2);

      const parsedFolder1: FolderModel = {
        name: folder1.name,
        description: folder1.description,
        id: folder1.id,
      };

      const parsedFolder2: FolderModel = {
        name: folder2.name,
        description: folder2.description,
        id: folder2.id,
      };

      const expectedFolders: GetAllUserFoldersResDTO = {
        folders: expect.arrayContaining([parsedFolder1, parsedFolder2]),
      };

      expect(body).toEqual(expectedFolders);
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).get(`/folders`);

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });

  describe('GET /folders/:folderId', () => {
    it(`should return specific user folder`, async () => {
      const folder1 = await factory.addFolder({
        name: 'folder1',
        description: 'folder1 desc',
        userId: user.id,
      });

      const { body } = await request(app.getHttpServer())
        .get(`/folders/${folder1.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      const parsedFolder1: FolderModel = {
        name: folder1.name,
        description: folder1.description,
        id: folder1.id,
      };

      expect(body).toEqual(parsedFolder1);
    });

    it(`fails when folder does not belong to user`, async () => {
      const otherUser = await factory.addUser({
        email: 'test2@test.test',
        password: '123123123',
        name: 'TestUser2',
      });

      const folder1 = await factory.addFolder({
        name: 'folder1',
        description: 'folder1 desc',
        userId: otherUser.id,
      });

      const { body } = await request(app.getHttpServer())
        .get(`/folders/${folder1.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body).toEqual({
        error: 'Bad Request',
        statusCode: 400,
        message: MSG.FOLDER_DOES_NOT_BELONG_TO_USER,
      });
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).get(
        `/folders/2323432`,
      );

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });

  describe('POST /folders', () => {
    it(`should add folder`, async () => {
      const requestData: CreateFolderDto = {
        description: 'test folder to add',
        name: 'test folder',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/folders`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(201);

      const expectedFolder: FolderModel = {
        description: requestData.description,
        name: requestData.name,
        id: expect.any(String),
      };

      expect(body).toEqual(expectedFolder);

      const userFolders = await factory.getUserFolders(user.id);
      expect(userFolders).toHaveLength(1);

      expect(userFolders[0]).toEqual(expectedFolder);
    });

    it('fails when user already has a folder with the same name', async () => {
      const existingFolder = await factory.addFolder({
        userId: user.id,
        name: 'existing folder name',
      });

      const req: CreateFolderDto = {
        description: 'folder description',
        name: existingFolder.name,
      };

      const { body } = await request(app.getHttpServer())
        .post(`/folders`)
        .send(req)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toBe(MSG.FOLDER_NAME_DUPLICATE);
    });

    it('fails when required data is missing', async () => {
      const requestData: Partial<CreateFolderDto> = {
        name: 'test folder',
      };

      const { body } = await request(app.getHttpServer())
        .post(`/folders`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(400);

      expect(body.message).toEqual(
        expect.arrayContaining(['description should not be empty']),
      );
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).post(`/folders`);

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });

  describe('PATCH /folders/:folderId', () => {
    it(`should update folder`, async () => {
      const userFolder = await factory.addFolder({
        name: 'folder1',
        description: 'folder1 desc',
        userId: user.id,
      });

      const requestData: UpdateFolderDto = {
        name: 'updated name',
        description: 'updated desc',
      };

      const { body } = await request(app.getHttpServer())
        .patch(`/folders/${userFolder.id}`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      const expectedFolder: FolderModel = {
        name: requestData.name as string,
        description: requestData.description as string,
        id: userFolder.id,
      };

      expect(body).toEqual(expectedFolder);

      const userFolders = await factory.getUserFolders(user.id);
      expect(userFolders).toHaveLength(1);

      expect(userFolders[0]).toEqual(expectedFolder);
    });

    it('allows to update partial data', async () => {
      const userFolder = await factory.addFolder({
        name: 'folder1',
        description: 'folder1 desc',
        userId: user.id,
      });

      const requestData: UpdateFolderDto = {
        name: 'updated name',
      };

      const { body } = await request(app.getHttpServer())
        .patch(`/folders/${userFolder.id}`)
        .send(requestData)
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      const expectedFolder: FolderModel = {
        name: requestData.name as string,
        description: userFolder.description,
        id: userFolder.id,
      };

      expect(body).toEqual(expectedFolder);

      const userFolders = await factory.getUserFolders(user.id);
      expect(userFolders).toHaveLength(1);

      expect(userFolders[0]).toEqual(expectedFolder);
    });

    it(`fails when folder does not belong to user`, async () => {
      const otherUser = await factory.addUser({
        email: 'test2@test.test',
        password: '123123123',
        name: 'TestUser2',
      });

      const folder1 = await factory.addFolder({
        name: 'folder1',
        description: 'folder1 desc',
        userId: otherUser.id,
      });

      const requestData: UpdateFolderDto = {
        name: 'updated name',
      };

      const { body } = await request(app.getHttpServer())
        .patch(`/folders/${folder1.id}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .send(requestData)
        .expect(400);

      expect(body).toEqual({
        error: 'Bad Request',
        statusCode: 400,
        message: MSG.FOLDER_DOES_NOT_BELONG_TO_USER,
      });
    });

    it('fails without authentication token', async () => {
      const { body } = await request(app.getHttpServer()).patch(`/folders/123`);

      expect(body).toEqual({
        statusCode: 401,
        message: 'Unauthorized',
      });
    });
  });
});

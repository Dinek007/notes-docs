import { FaunaQuery, Ref } from '../types';
import { FolderModel } from './folders.dto';

export type FolderDbData = Omit<FolderModel, 'id'> & {
  user: Ref;
};
export type FolderQueryResult = FaunaQuery<FolderDbData>;
export type FoldersQueryResult = FaunaQuery<FaunaQuery<FolderDbData>[]>;
export type LoginQueryResult = { instance: string };

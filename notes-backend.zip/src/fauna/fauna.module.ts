import { FaunadbModule, FaunadbModuleOptions } from 'nestjs-faunadb';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { Config } from '../config/config.types';
import { DynamicModule, Module } from '@nestjs/common';

@Module({})
export class FaunaModule {
  static register(secret?: string): DynamicModule {
    return FaunadbModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (config: ConfigService<Config, true>) => {
        const fdbConfig: FaunadbModuleOptions = {
          ...config.get('db', {
            infer: true,
          }),
        };

        if (secret) {
          fdbConfig.secret = secret;
        }

        return fdbConfig;
      },
      inject: [ConfigService],
    });
  }
}
